# فهرس وثائق أوغاريت UGARIT — الإصدار 1.48

| الوثيقة | الغرض |
|---|---|
| `GUIDE_STUDENT_AR_v1.48.md` | دليل الطالب للتنقل والتعلم والخرائط والاختبارات والخصوصية |
| `GUIDE_TEACHER_AR_v1.48.md` | دليل المعلم للتدريس وبناء الأسئلة واستخدام الأدوات |
| `TECHNICAL_DOCUMENTATION_AR_v1.48.md` | البنية التقنية والبناء والتخزين والخرائط والأمن والنشر |
| `CONTENT_QUALITY_REPORT_v1.48_AR.md` | جرد المحتوى وتوزيع الأسئلة وحالة الجودة والمطابقة |
| `INSTITUTIONAL_READINESS_REPORT_AR_v1.48.md` | تقييم الجاهزية والفجوات وشروط العرض والتشغيل |
| `TASK4_REPORT_AR_v1.48.txt` | تقرير تنفيذ المهمة الرابعة ونتائج التحقق |

## وثائق تشغيل مساندة
راجع أيضاً: `README.txt`, `TASK1_REPORT_AR.txt`, `TASK2_REPORT_AR.txt`, `TASK3_REPORT_AR.txt`, `SOURCE_REGISTER_v1.46_AR.md`, `CURRICULUM_ALIGNMENT_STATUS_v1.46_AR.md`, `QUESTION_BANK_AUDIT_v1.46_AR.md`, `HOSTING_AR.txt`, `LAUNCH_CHECKLIST_AR.txt`, `RESTORE_AR.txt`, و`BACKUP_MANIFEST_sha256.txt`.
