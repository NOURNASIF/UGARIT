# فهرس وثائق أوغاريت UGARIT — الإصدار 0.1.10

| الوثيقة | الغرض |
|---|---|
| `README.txt` | تعريف الحزمة وطريقة تشغيل الواجهة وحدود الإصدار |
| `AUDIT_REPORT_AR_v0.1.10.md` | تقرير التدقيق الفني والتعليمي ونتائج الاختبارات والفجوات |
| `CHANGELOG_v0.1.10_AR.md` | الإصلاحات التي دخلت هذا الإصدار |
| `SOURCE_REGISTER_v0.1.10_AR.md` | المصادر الرسمية والمراجع وسياسة توثيق المحتوى |
| `CURRICULUM_ALIGNMENT_STATUS_v0.1.10_AR.md` | حالة مطابقة المنهاج السوري للعام الدراسي 2026–2027 صفاً بصف |
| `GUIDE_STUDENT_AR_v1.48.md` | دليل الطالب |
| `GUIDE_TEACHER_AR_v1.48.md` | دليل المعلم |
| `TECHNICAL_DOCUMENTATION_AR_v1.48.md` | البنية التقنية والتخزين والخرائط والأمن |
| `CONTENT_QUALITY_REPORT_v1.48_AR.md` | جرد المحتوى السابق وتوزيع الأسئلة |
| `INSTITUTIONAL_READINESS_REPORT_AR_v1.48.md` | الجاهزية المؤسسية والفجوات التشغيلية |
| `QUESTION_BANK_AUDIT_v1.46_AR.md` | تدقيق بنك الأسئلة السابق |
| `API_SECURITY_REVIEW_AR_v1.49.md` | مراجعة أساس أمان API |
| `INSTITUTIONAL_ARCHITECTURE_AR_v1.49.md` | معمارية الأساس المؤسسي |

## وثائق التشغيل والاستعادة

راجع أيضاً `APPWRITE_SETUP_AR.md`, `HOSTING_AR.txt`, `LAUNCH_CHECKLIST_AR.txt`, `RESTORE_AR.txt`, `BACKUP_MANIFEST_sha256.txt` وملفات `backend/`.

**تنبيه:** الوثائق الأقدم محفوظة كسجل تاريخي للإصدارات السابقة. عند التعارض، يُقدّم تقرير التدقيق v0.1.10 وسجل المصادر وحالة مطابقة المنهاج v0.1.10.
