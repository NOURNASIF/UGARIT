import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const required = [
  'index.html','manifest.webmanifest','sw.js','geoverse-logo.png',
  'geoverse-icon-192.png','geoverse-icon-512.png','geoverse-mark.svg',
  'netlify.toml','netlify/functions/admin-portal.mjs',
  'backend/.env.example','backend/src/server.js'
];
for (const f of required) if (!fs.existsSync(path.join(root,f))) errors.push(`missing: ${f}`);
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const manifest = JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'));
const sw = fs.readFileSync(path.join(root,'sw.js'),'utf8');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
if (pkg.version !== '0.1.37') errors.push(`package version is ${pkg.version}, expected 0.1.37`);
if (manifest.version !== pkg.version) errors.push('manifest/package version mismatch');
if (!sw.includes(`geoverse-shell-v${pkg.version}-m36`)) errors.push('service worker cache key/version mismatch');
for (const icon of manifest.icons || []) if (!fs.existsSync(path.join(root,icon.src.replace(/^\.\//,'')))) errors.push(`manifest icon missing: ${icon.src}`);
if (!html.includes('GeoVerse') || !html.includes('جيو فيرس')) errors.push('GeoVerse bilingual identity marker missing in built HTML');
if (html.includes('YOUR-GEOVERSE-SITE.netlify.app')) errors.push('placeholder deployment host leaked into built HTML');
if (errors.length) { console.error('GeoVerse pre-deploy check: FAILED'); for (const e of errors) console.error(`- ${e}`); process.exit(1); }
console.log('GeoVerse pre-deploy check: PASS');
console.log(`Version: ${pkg.version}`);
console.log(`Required release files: ${required.length} present`);
console.log('Note: this local check does not verify live browser behavior, hosted API, database, DNS, or provider environment variables.');
