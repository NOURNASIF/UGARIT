'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const server=fs.readFileSync(path.join(__dirname,'../src/server.js'),'utf8');
const migration=fs.readFileSync(path.join(__dirname,'../migrations/003_class_assessment_reporting.sql'),'utf8');

test('student reporting endpoint requires an authenticated student role and active enrollment',()=>{
  assert.ok(server.includes("classAttemptsMatch&&method==='POST'"));
  assert.ok(server.includes("roles('student')(u)"));
  assert.ok(server.includes("e.student_id=$2 AND cl.organization_id=$3 AND e.status='active' AND cl.status='active'"));
});
test('student submissions validate score bounds, duration, topic and summary payloads',()=>{
  assert.ok(server.includes('score>maxScore'));
  assert.ok(server.includes('duration>14400'));
  assert.ok(server.includes("cleanSummary(b.skills,'skill')"));
  assert.ok(server.includes("cleanSummary(b.topics,'topic')"));
  assert.ok(server.includes('answers_json,started_at,submitted_at'));
});
test('teacher reporting is limited to assigned classes and school administrators to their organization',()=>{
  assert.ok(server.includes("roles('teacher','school_admin','directorate_admin')(u)"));
  assert.ok(server.includes("teacher_id=$2 AND $3='teacher'"));
  assert.ok(server.includes("organization_id=$4 AND $3 IN ('school_admin','directorate_admin')"));
  assert.ok(server.includes("scope:'authorized_class'"));
});
test('database row-level security enforces student ownership and class-scoped staff access',()=>{
  assert.ok(migration.includes('DROP POLICY IF EXISTS attempts_owner_or_staff'));
  assert.ok(migration.includes('CREATE POLICY attempts_owner_or_assigned_staff'));
  assert.ok(migration.includes("student_id = NULLIF(current_setting('app.user_id',true),'')::uuid"));
  assert.ok(migration.includes("cl.teacher_id = NULLIF(current_setting('app.user_id',true),'')::uuid"));
  assert.ok(migration.includes("e.status='active' AND cl.status='active'"));
});
test('migration adds only summarized class reporting fields and no raw response payload column',()=>{
  for(const field of ['class_id','grade_level','topic','percent','duration_seconds','skills_json','topics_json'])assert.ok(migration.includes('ADD COLUMN IF NOT EXISTS '+field));
  assert.doesNotMatch(migration,/ADD COLUMN[^;]*(student_email|password|raw_answers)/i);
});

test('teacher class discovery returns only classes assigned to the authenticated teacher',()=>{
  assert.ok(server.includes("if(u.role==='teacher')return (await c.query('SELECT id,name,grade_level,academic_year,status FROM classes WHERE teacher_id=$1"));
});

test('class creation validates a numeric grade level supported by assessment reporting',()=>{
  assert.ok(server.includes("!/^([1-9]|1[0-2])$/.test(gradeLevel)"));
  assert.ok(server.includes('b.name.trim(),gradeLevel,b.academicYear,u.role===\'teacher\'?u.id:null')); 
});
