'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const server=fs.readFileSync(path.join(__dirname,'../src/server.js'),'utf8');
const migration=fs.readFileSync(path.join(__dirname,'../migrations/004_classroom_administration.sql'),'utf8');

test('M9 class assignment changes are restricted to organization administrators and platform administrators',()=>{
  assert.ok(server.includes("classAdminMatch&&method==='PATCH'"));
  assert.ok(server.includes("roles('school_admin','directorate_admin','platform_admin')(u)"));
  assert.ok(server.includes("teacher_not_active_in_organization"));
  assert.ok(server.includes("['active','archived']"));
});
test('M9 roster reads enforce assigned teacher or authorized organization scope',()=>{
  assert.ok(server.includes("rosterMatch&&method==='GET'"));
  assert.ok(server.includes("teacher_id=$2 AND $3='teacher'"));
  assert.ok(server.includes("organization_id=$4 AND $3 IN ('school_admin','directorate_admin')"));
  assert.ok(server.includes("scope:'authorized_class_roster'"));
});
test('M9 enrollment requires an active student in the same organization and an active class',()=>{
  assert.ok(server.includes("rosterMatch&&method==='POST'"));
  assert.ok(server.includes("cl.status!=='active'"));
  assert.ok(server.includes("role='student' AND status='active'"));
  assert.ok(server.includes("ON CONFLICT(class_id,student_id) DO UPDATE SET status='active'"));
});
test('M9 withdrawal marks enrollment inactive without deleting assessment history',()=>{
  assert.ok(server.includes("withdrawMatch&&method==='DELETE'"));
  assert.ok(server.includes("UPDATE enrollments SET status='withdrawn'"));
  assert.doesNotMatch(server,/DELETE FROM assessment_attempts/);
});
test('M9 administrative user filters accept only known roles and statuses',()=>{
  assert.ok(server.includes('invalid_user_filter'));
  assert.ok(server.includes("['pending','active','suspended']"));
  assert.ok(server.includes('role=$2'));
});
test('M9 migration adds platform-aware row policies while preserving tenant scoping',()=>{
  assert.ok(migration.includes("current_setting('app.user_role',true)='platform_admin'"));
  assert.ok(migration.includes('CREATE POLICY profile_admin_insert'));
  assert.ok(migration.includes('idx_enrollments_student_status'));
});
test('M9 staff account creation hashes credentials and restricts role creation by administrator type',()=>{
  assert.ok(server.includes("path==='/api/v1/admin/users'&&method==='POST'"));
  assert.ok(server.includes("u.role==='school_admin'||u.role==='directorate_admin'?['teacher']"));
  assert.ok(server.includes("u.role==='school_admin'||u.role==='directorate_admin'?['teacher']"));
  assert.ok(server.includes('const passwordHash=await hashPassword(b.password)'));
  assert.ok(server.includes('INSERT INTO auth_credentials(user_id,email,password_hash)'));
});
test('M9 platform organization listing is platform-admin only and organization assignment is supported',()=>{
  assert.ok(server.includes("path==='/api/v1/admin/organizations'&&method==='GET'"));
  assert.ok(server.includes("roles('platform_admin')(u)"));
  assert.ok(server.includes("const org=b.organizationId||null"));
  assert.ok(server.includes("['pending','active','suspended']"));
});

test('M10 bulk enrollment validates a bounded unique email list and resolves active students inside the class organization',()=>{
 assert.ok(server.includes('if(Array.isArray(b.emails))'));
 assert.ok(server.includes('emails.length>100'));
 assert.ok(server.includes("p.role='student' AND p.status='active'"));
 assert.ok(server.includes('p.organization_id=$2'));
 assert.ok(server.includes('added,rejected,received:emails.length'));
});
