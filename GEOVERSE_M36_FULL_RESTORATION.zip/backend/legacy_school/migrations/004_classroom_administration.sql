-- UGARIT M9: scoped class administration and roster management.
-- Apply after migrations 001, 002 and 003 as the schema owner.
BEGIN;

-- Platform administrators may operate across organizations only through explicit API scope checks.
DROP POLICY IF EXISTS classes_org_read ON classes;
CREATE POLICY classes_org_read ON classes FOR SELECT USING (
  organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid
  OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS classes_staff_write ON classes;
CREATE POLICY classes_staff_write ON classes FOR ALL USING (
  (organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid
   AND current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin'))
  OR current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (
  (organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid
   AND current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin'))
  OR current_setting('app.user_role',true)='platform_admin'
);

DROP POLICY IF EXISTS enrollments_org_read ON enrollments;
CREATE POLICY enrollments_org_read ON enrollments FOR SELECT USING (
  student_id=NULLIF(current_setting('app.user_id',true),'')::uuid
  OR class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid)
  OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS enrollments_staff_write ON enrollments;
CREATE POLICY enrollments_staff_write ON enrollments FOR ALL USING (
  (current_setting('app.user_role',true) IN ('school_admin','directorate_admin')
   AND class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid))
  OR (current_setting('app.user_role',true)='platform_admin'
      AND class_id IN (SELECT id FROM classes))
) WITH CHECK (
  (current_setting('app.user_role',true) IN ('school_admin','directorate_admin')
   AND class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid))
  OR (current_setting('app.user_role',true)='platform_admin'
      AND class_id IN (SELECT id FROM classes))
);

-- Organization administrators may create teacher profiles only inside their own organization.
DROP POLICY IF EXISTS profile_admin_insert ON user_profiles;
CREATE POLICY profile_admin_insert ON user_profiles FOR INSERT WITH CHECK (
  (organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid
   AND current_setting('app.user_role',true) IN ('school_admin','directorate_admin'))
  OR current_setting('app.user_role',true)='platform_admin'
);

CREATE INDEX IF NOT EXISTS idx_enrollments_student_status ON enrollments(student_id,status);
CREATE INDEX IF NOT EXISTS idx_classes_org_status_grade ON classes(organization_id,status,grade_level);
COMMIT;
