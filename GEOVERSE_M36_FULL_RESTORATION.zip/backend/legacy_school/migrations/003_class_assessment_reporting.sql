-- UGARIT M7: class-scoped assessment reporting with student ownership and staff scope.
-- Apply as schema owner after migrations 001 and 002. Backward compatible: existing local-only records are untouched.
BEGIN;
ALTER TABLE assessment_attempts
  ADD COLUMN IF NOT EXISTS class_id uuid REFERENCES classes(id) ON DELETE RESTRICT,
  ADD COLUMN IF NOT EXISTS grade_level smallint CHECK (grade_level IS NULL OR grade_level BETWEEN 1 AND 12),
  ADD COLUMN IF NOT EXISTS topic text,
  ADD COLUMN IF NOT EXISTS percent numeric(5,2) CHECK (percent IS NULL OR percent BETWEEN 0 AND 100),
  ADD COLUMN IF NOT EXISTS duration_seconds integer CHECK (duration_seconds IS NULL OR duration_seconds BETWEEN 0 AND 14400),
  ADD COLUMN IF NOT EXISTS skills_json jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS topics_json jsonb NOT NULL DEFAULT '[]'::jsonb;
CREATE INDEX IF NOT EXISTS idx_attempts_class_date ON assessment_attempts(class_id, submitted_at DESC) WHERE class_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_attempts_class_student ON assessment_attempts(class_id, student_id) WHERE class_id IS NOT NULL;

-- Replace the earlier broad staff-read rule with assigned-class / same-organization scope.
DROP POLICY IF EXISTS attempts_owner_or_staff ON assessment_attempts;
DROP POLICY IF EXISTS attempts_owner_or_assigned_staff ON assessment_attempts;
CREATE POLICY attempts_owner_or_assigned_staff ON assessment_attempts FOR SELECT USING (
  student_id = NULLIF(current_setting('app.user_id',true),'')::uuid
  OR (
    class_id IS NOT NULL AND EXISTS (
      SELECT 1 FROM classes cl
      WHERE cl.id = assessment_attempts.class_id
        AND (
          (cl.teacher_id = NULLIF(current_setting('app.user_id',true),'')::uuid AND current_setting('app.user_role',true)='teacher')
          OR (cl.organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid
              AND current_setting('app.user_role',true) IN ('school_admin','directorate_admin'))
        )
    )
  )
);
DROP POLICY IF EXISTS attempts_student_insert ON assessment_attempts;
CREATE POLICY attempts_student_insert ON assessment_attempts FOR INSERT WITH CHECK (
  student_id = NULLIF(current_setting('app.user_id',true),'')::uuid
  AND class_id IS NOT NULL
  AND EXISTS (
    SELECT 1 FROM enrollments e JOIN classes cl ON cl.id=e.class_id
    WHERE e.class_id=assessment_attempts.class_id
      AND e.student_id=NULLIF(current_setting('app.user_id',true),'')::uuid
      AND e.status='active' AND cl.status='active'
  )
);

-- Permit a teacher to resolve names only for students enrolled in classes assigned to that teacher.
DROP POLICY IF EXISTS profile_teacher_class_students ON user_profiles;
CREATE POLICY profile_teacher_class_students ON user_profiles FOR SELECT USING (
  current_setting('app.user_role',true)='teacher'
  AND EXISTS (
    SELECT 1 FROM enrollments e JOIN classes cl ON cl.id=e.class_id
    WHERE e.student_id=user_profiles.id AND e.status='active'
      AND cl.teacher_id=NULLIF(current_setting('app.user_id',true),'')::uuid
  )
);
COMMIT;
