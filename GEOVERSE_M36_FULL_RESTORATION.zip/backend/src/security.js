'use strict';
const crypto = require('node:crypto');
function b64url(v){return Buffer.from(v).toString('base64url');}
function signAccessToken(payload, secret, ttl=900){
  const now=Math.floor(Date.now()/1000),head=b64url(JSON.stringify({alg:'HS256',typ:'JWT'}));
  const body=b64url(JSON.stringify({...payload,iat:now,exp:now+ttl}));
  const sig=crypto.createHmac('sha256',secret).update(`${head}.${body}`).digest('base64url');
  return `${head}.${body}.${sig}`;
}
function verifyAccessToken(token,secret){
  const parts=String(token||'').split('.');if(parts.length!==3)throw new Error('invalid_token');
  if(!/^[A-Za-z0-9_-]+$/.test(parts[2]))throw new Error('invalid_token');
  const expected=crypto.createHmac('sha256',secret).update(`${parts[0]}.${parts[1]}`).digest('base64url');
  const actualBytes=Buffer.from(parts[2],'utf8'),expectedBytes=Buffer.from(expected,'utf8');
  // Compare the canonical encoded signature; permissive base64url decoding can accept alternate trailing-bit encodings.
  if(actualBytes.length!==expectedBytes.length||!crypto.timingSafeEqual(actualBytes,expectedBytes))throw new Error('invalid_token');
  const p=JSON.parse(Buffer.from(parts[1],'base64url').toString('utf8'));
  if(!p.sub||!p.exp||p.exp<=Math.floor(Date.now()/1000))throw new Error('expired_token');return p;
}
function hashPassword(password){return new Promise((resolve,reject)=>{
  const salt=crypto.randomBytes(16);crypto.scrypt(password,salt,64,{N:16384,r:8,p:1},(e,key)=>e?reject(e):resolve(`scrypt$16384$8$1$${salt.toString('base64url')}$${key.toString('base64url')}`));
});}
function verifyPassword(password,stored){return new Promise((resolve,reject)=>{
  try{const [scheme,N,r,p,salt,key]=stored.split('$');if(scheme!=='scrypt')return resolve(false);const expected=Buffer.from(key,'base64url');crypto.scrypt(password,Buffer.from(salt,'base64url'),expected.length,{N:Number(N),r:Number(r),p:Number(p)},(e,actual)=>e?reject(e):resolve(actual.length===expected.length&&crypto.timingSafeEqual(actual,expected)));}catch(_){resolve(false);}
});}
function randomToken(){return crypto.randomBytes(48).toString('base64url');}
function sha256(v){return crypto.createHash('sha256').update(v).digest('hex');}
module.exports={signAccessToken,verifyAccessToken,hashPassword,verifyPassword,randomToken,sha256};
