'use strict';
const {sha256}=require('./security');
const SCHOOL_ROLES=Object.freeze(['school_admin','school_teacher','school_staff']);
function hashSchoolActivationKey(key){if(typeof key!=='string'||key.length<32||key.length>200)throw new Error('invalid_school_activation_key');return sha256(key);}
function normalizeSchoolSlug(value){return typeof value==='string'?value.trim().toLowerCase():'';}
function validSchoolSlug(value){return /^[a-z0-9][a-z0-9-]{2,59}$/.test(normalizeSchoolSlug(value));}
function validSchoolRole(value){return SCHOOL_ROLES.includes(value);}
function schoolTokenClaims(user,ttl=900){if(!user||!user.id||!user.organization_id||!validSchoolRole(user.role))throw new Error('invalid_school_identity');return {sub:user.id,aud:'ugarit-school',orgId:user.organization_id,role:user.role};}
module.exports={SCHOOL_ROLES,hashSchoolActivationKey,normalizeSchoolSlug,validSchoolSlug,validSchoolRole,schoolTokenClaims};
