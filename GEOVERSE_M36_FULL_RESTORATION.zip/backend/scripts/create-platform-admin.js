'use strict';
const {Pool}=require('pg');
const {hashPassword}=require('../src/security');
(async()=>{
 const {DATABASE_URL,ADMIN_BOOTSTRAP_DATABASE_URL,ADMIN_EMAIL,ADMIN_NAME,ADMIN_PASSWORD,DATABASE_SSL}=process.env;const connectionString=ADMIN_BOOTSTRAP_DATABASE_URL||DATABASE_URL;
 if(!connectionString||!ADMIN_EMAIL||!ADMIN_NAME||!ADMIN_PASSWORD||ADMIN_PASSWORD.length<14){console.error('Set DATABASE_URL, ADMIN_EMAIL, ADMIN_NAME, and ADMIN_PASSWORD (14+ chars) in the secure server environment.');process.exit(1);}
 const pool=new Pool({connectionString,ssl:DATABASE_SSL==='true'?{rejectUnauthorized:true}:undefined});
 const c=await pool.connect();try{
  await c.query('BEGIN');await c.query("SELECT pg_advisory_xact_lock(hashtext('ugarit-platform-admin-bootstrap'))");
  const exists=await c.query("SELECT 1 FROM user_profiles WHERE role='platform_admin' LIMIT 1");if(exists.rowCount){throw new Error('A platform administrator already exists; bootstrap is disabled.');}
  const id=(await c.query("INSERT INTO user_profiles(id,full_name,role,status) VALUES(gen_random_uuid(),$1,'platform_admin','active') RETURNING id",[ADMIN_NAME.trim()])).rows[0].id;
  await c.query('INSERT INTO auth_credentials(user_id,email,password_hash) VALUES($1,$2,$3)',[id,ADMIN_EMAIL.trim().toLowerCase(),await hashPassword(ADMIN_PASSWORD)]);
  await c.query('COMMIT');console.log('Initial platform administrator created. Remove bootstrap credentials from the environment now.');
 }catch(e){await c.query('ROLLBACK');console.error(e.message);process.exitCode=1;}finally{c.release();await pool.end();}
})();
