'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {hashSchoolActivationKey,normalizeSchoolSlug,validSchoolSlug,validSchoolRole,schoolTokenClaims}=require('../src/school-security');
const {signAccessToken,verifyAccessToken}=require('../src/security');

test('school activation keys are stored as irreversible SHA-256 digests',()=>{
 const key='a-strong-one-time-school-activation-key';
 const digest=hashSchoolActivationKey(key);
 assert.match(digest,/^[a-f0-9]{64}$/);
 assert.notEqual(digest,key);
 assert.equal(hashSchoolActivationKey(key),digest);
 assert.throws(()=>hashSchoolActivationKey('short'));
});
test('school slugs are normalized and strictly validated',()=>{
 assert.equal(normalizeSchoolSlug('  ALEPPO-SCHOOL  '),'aleppo-school');
 assert.equal(validSchoolSlug('aleppo-school'),true);
 for(const value of ['ab','has spaces','-bad','bad_underscore','bad/route'])assert.equal(validSchoolSlug(value),false);
});
test('school roles cannot be escalated to platform or educational roles',()=>{
 assert.equal(validSchoolRole('school_admin'),true);
 assert.equal(validSchoolRole('school_teacher'),true);
 assert.equal(validSchoolRole('school_staff'),true);
 for(const value of ['platform_admin','teacher','student','admin'])assert.equal(validSchoolRole(value),false);
});
test('school access tokens carry a distinct audience and tenant identifier',()=>{
 const claims=schoolTokenClaims({id:'u-1',organization_id:'org-1',role:'school_admin'});
 const token=signAccessToken(claims,'test-secret-that-is-at-least-32-characters-long',60);
 const decoded=verifyAccessToken(token,'test-secret-that-is-at-least-32-characters-long');
 assert.equal(decoded.aud,'ugarit-school');
 assert.equal(decoded.orgId,'org-1');
 assert.equal(decoded.role,'school_admin');
 assert.throws(()=>schoolTokenClaims({id:'u',organization_id:'o',role:'platform_admin'}));
});
