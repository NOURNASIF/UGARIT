-- UGARIT M19: operational query indexes for multi-school workflows.
-- Apply after migrations 006 and 007. No tenant data is rewritten.
BEGIN;
CREATE INDEX IF NOT EXISTS idx_school_classes_year ON school_classes(organization_id,academic_year_id,name);
CREATE INDEX IF NOT EXISTS idx_school_students_name ON school_students(organization_id,full_name);
CREATE INDEX IF NOT EXISTS idx_school_attendance_date_class ON school_attendance_records(organization_id,attendance_date,class_id);
CREATE INDEX IF NOT EXISTS idx_school_assignments_due ON school_assignments(organization_id,status,due_at);
CREATE INDEX IF NOT EXISTS idx_school_lesson_plans_recent ON school_lesson_plans(organization_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_school_assessments_class_date ON school_assessments(organization_id,class_id,assessment_date DESC);
CREATE INDEX IF NOT EXISTS idx_school_results_student ON school_assessment_results(organization_id,student_id,created_at DESC);
COMMIT;
