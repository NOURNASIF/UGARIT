-- UGARIT M18: core operational records, all scoped to one school organization.
BEGIN;
CREATE TABLE IF NOT EXISTS school_academic_years (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 title text NOT NULL CHECK(length(trim(title)) BETWEEN 3 AND 80), starts_on date NOT NULL, ends_on date NOT NULL,
 is_current boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(), CHECK(ends_on>=starts_on), UNIQUE(id,organization_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_school_one_current_year ON school_academic_years(organization_id) WHERE is_current=true;
CREATE TABLE IF NOT EXISTS school_classes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 academic_year_id uuid NOT NULL, name text NOT NULL CHECK(length(trim(name)) BETWEEN 1 AND 100), grade_level text,
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,organization_id),
 FOREIGN KEY(academic_year_id,organization_id) REFERENCES school_academic_years(id,organization_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS school_students (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 class_id uuid NOT NULL, student_code text, full_name text NOT NULL CHECK(length(trim(full_name)) BETWEEN 2 AND 160),
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','graduated','transferred')),
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,organization_id),
 FOREIGN KEY(class_id,organization_id) REFERENCES school_classes(id,organization_id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_school_student_code ON school_students(organization_id,student_code) WHERE student_code IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_school_students_class ON school_students(organization_id,class_id,status);
CREATE TABLE IF NOT EXISTS school_attendance_records (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 student_id uuid NOT NULL, class_id uuid NOT NULL, attendance_date date NOT NULL,
 status text NOT NULL CHECK(status IN ('present','absent','late','excused')),
 note text, recorded_by uuid REFERENCES school_users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(student_id,organization_id) REFERENCES school_students(id,organization_id) ON DELETE CASCADE,
 FOREIGN KEY(class_id,organization_id) REFERENCES school_classes(id,organization_id) ON DELETE CASCADE,
 UNIQUE(student_id,attendance_date)
);
CREATE TABLE IF NOT EXISTS school_assignments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 class_id uuid NOT NULL, title text NOT NULL CHECK(length(trim(title)) BETWEEN 2 AND 200), description text,
 due_at timestamptz, status text NOT NULL DEFAULT 'active' CHECK(status IN ('draft','active','archived')),
 created_by uuid REFERENCES school_users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(class_id,organization_id) REFERENCES school_classes(id,organization_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS school_lesson_plans (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 class_id uuid, title text NOT NULL CHECK(length(trim(title)) BETWEEN 2 AND 200), subject text NOT NULL DEFAULT 'geography',
 objectives jsonb NOT NULL DEFAULT '[]'::jsonb, activities jsonb NOT NULL DEFAULT '[]'::jsonb,
 status text NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','ready','archived')),
 created_by uuid REFERENCES school_users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(class_id,organization_id) REFERENCES school_classes(id,organization_id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS school_assessments (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 class_id uuid NOT NULL, title text NOT NULL CHECK(length(trim(title)) BETWEEN 2 AND 200), total_score numeric(7,2) NOT NULL CHECK(total_score>0),
 assessment_date date, created_by uuid REFERENCES school_users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(id,organization_id),
 FOREIGN KEY(class_id,organization_id) REFERENCES school_classes(id,organization_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS school_assessment_results (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 assessment_id uuid NOT NULL, student_id uuid NOT NULL, score numeric(7,2) NOT NULL CHECK(score>=0), note text,
 recorded_by uuid REFERENCES school_users(id) ON DELETE SET NULL, created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY(assessment_id,organization_id) REFERENCES school_assessments(id,organization_id) ON DELETE CASCADE,
 FOREIGN KEY(student_id,organization_id) REFERENCES school_students(id,organization_id) ON DELETE CASCADE,
 UNIQUE(assessment_id,student_id)
);

DO $$ DECLARE t text; BEGIN
 FOREACH t IN ARRAY ARRAY['school_academic_years','school_classes','school_students','school_attendance_records','school_assignments','school_lesson_plans','school_assessments','school_assessment_results'] LOOP
  EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY',t);
  EXECUTE format('DROP POLICY IF EXISTS %I ON %I',t||'_tenant_isolation',t);
  EXECUTE format('CREATE POLICY %I ON %I FOR ALL USING (organization_id=NULLIF(current_setting(''app.school_org_id'',true),'''')::uuid) WITH CHECK (organization_id=NULLIF(current_setting(''app.school_org_id'',true),'''')::uuid)',t||'_tenant_isolation',t);
 END LOOP;
END $$;
COMMIT;
