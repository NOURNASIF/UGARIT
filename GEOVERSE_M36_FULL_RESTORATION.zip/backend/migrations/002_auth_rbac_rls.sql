-- UGARIT M16: standalone teacher authentication, resource permissions and audit controls.
BEGIN;
CREATE TABLE IF NOT EXISTS auth_credentials (
 user_id uuid PRIMARY KEY REFERENCES user_profiles(id) ON DELETE CASCADE,
 email text NOT NULL UNIQUE,
 password_hash text NOT NULL,
 last_login_at timestamptz,
 password_changed_at timestamptz NOT NULL DEFAULT now(),
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK (email=lower(email))
);
CREATE INDEX IF NOT EXISTS idx_credentials_email ON auth_credentials(email);
CREATE OR REPLACE FUNCTION ugarit_auth_lookup(p_email text)
RETURNS TABLE(id uuid,full_name text,role text,status text,password_hash text)
LANGUAGE sql SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT p.id,p.full_name,p.role,p.status,c.password_hash FROM auth_credentials c JOIN user_profiles p ON p.id=c.user_id WHERE c.email=lower(p_email) LIMIT 1
$$;
CREATE OR REPLACE FUNCTION ugarit_profile_lookup(p_user_id uuid)
RETURNS TABLE(id uuid,full_name text,role text,status text)
LANGUAGE sql SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT p.id,p.full_name,p.role,p.status FROM user_profiles p WHERE p.id=p_user_id LIMIT 1
$$;
REVOKE ALL ON FUNCTION ugarit_auth_lookup(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION ugarit_profile_lookup(uuid) FROM PUBLIC;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS profile_self_read ON user_profiles;
CREATE POLICY profile_self_read ON user_profiles FOR SELECT USING (
 id=NULLIF(current_setting('app.user_id',true),'')::uuid OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS profile_platform_update ON user_profiles;
CREATE POLICY profile_platform_update ON user_profiles FOR UPDATE USING (
 current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (current_setting('app.user_role',true)='platform_admin');
DROP POLICY IF EXISTS resources_public_or_owner_read ON learning_resources;
CREATE POLICY resources_public_or_owner_read ON learning_resources FOR SELECT USING (
 publication_status='published' OR created_by=NULLIF(current_setting('app.user_id',true),'')::uuid OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS resources_teacher_write ON learning_resources;
CREATE POLICY resources_teacher_write ON learning_resources FOR ALL USING (
 created_by=NULLIF(current_setting('app.user_id',true),'')::uuid AND current_setting('app.user_role',true)='teacher'
 OR current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (
 created_by=NULLIF(current_setting('app.user_id',true),'')::uuid AND current_setting('app.user_role',true)='teacher'
 OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS audit_platform_read ON audit_logs;
CREATE POLICY audit_platform_read ON audit_logs FOR SELECT USING (current_setting('app.user_role',true)='platform_admin');
COMMIT;
