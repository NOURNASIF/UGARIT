-- UGARIT M18: independent multi-school tenant identity and one-time activation keys.
-- Apply after 001, 002 and 005. Does not alter standalone student/teacher identities.
BEGIN;
CREATE TABLE IF NOT EXISTS school_organizations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL CHECK (length(trim(name)) BETWEEN 2 AND 180),
 slug text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9][a-z0-9-]{2,59}$'),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended','closed')),
 country_code char(2) NOT NULL DEFAULT 'SY',
 region text,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS school_activation_keys (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 key_hash char(64) NOT NULL UNIQUE,
 created_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
 expires_at timestamptz NOT NULL,
 consumed_at timestamptz,
 revoked_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(),
 CHECK (expires_at > created_at)
);
CREATE INDEX IF NOT EXISTS idx_school_activation_org ON school_activation_keys(organization_id,created_at DESC);
CREATE TABLE IF NOT EXISTS school_users (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 full_name text NOT NULL CHECK (length(trim(full_name)) BETWEEN 2 AND 160),
 email text NOT NULL CHECK (email=lower(email)),
 role text NOT NULL CHECK (role IN ('school_admin','school_teacher','school_staff')),
 status text NOT NULL DEFAULT 'active' CHECK (status IN ('pending','active','suspended')),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE (organization_id,email),
 UNIQUE (id,organization_id)
);
CREATE INDEX IF NOT EXISTS idx_school_users_org_role ON school_users(organization_id,role,status);
CREATE TABLE IF NOT EXISTS school_auth_credentials (
 user_id uuid PRIMARY KEY,
 organization_id uuid NOT NULL,
 password_hash text NOT NULL,
 last_login_at timestamptz,
 password_changed_at timestamptz NOT NULL DEFAULT now(),
 created_at timestamptz NOT NULL DEFAULT now(),
 FOREIGN KEY (user_id,organization_id) REFERENCES school_users(id,organization_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS school_audit_logs (
 id bigserial PRIMARY KEY,
 organization_id uuid NOT NULL REFERENCES school_organizations(id) ON DELETE CASCADE,
 actor_id uuid REFERENCES school_users(id) ON DELETE SET NULL,
 action text NOT NULL,
 entity_type text NOT NULL,
 entity_id text,
 metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_school_audit_org_date ON school_audit_logs(organization_id,created_at DESC);

ALTER TABLE school_organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE school_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE school_audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS school_org_tenant_read ON school_organizations;
CREATE POLICY school_org_tenant_read ON school_organizations FOR SELECT USING (
 id=NULLIF(current_setting('app.school_org_id',true),'')::uuid
 OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS school_org_platform_admin_manage ON school_organizations;
CREATE POLICY school_org_platform_admin_manage ON school_organizations FOR ALL USING (
 current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (current_setting('app.user_role',true)='platform_admin');
DROP POLICY IF EXISTS school_users_tenant_access ON school_users;
CREATE POLICY school_users_tenant_access ON school_users FOR ALL USING (
 organization_id=NULLIF(current_setting('app.school_org_id',true),'')::uuid
 OR current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (
 organization_id=NULLIF(current_setting('app.school_org_id',true),'')::uuid
 OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS school_audit_tenant_read ON school_audit_logs;
CREATE POLICY school_audit_tenant_read ON school_audit_logs FOR SELECT USING (
 organization_id=NULLIF(current_setting('app.school_org_id',true),'')::uuid
 OR current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS school_audit_tenant_insert ON school_audit_logs;
CREATE POLICY school_audit_tenant_insert ON school_audit_logs FOR INSERT WITH CHECK (
 organization_id=NULLIF(current_setting('app.school_org_id',true),'')::uuid
 AND actor_id=NULLIF(current_setting('app.school_user_id',true),'')::uuid
);
-- Authentication lookups are performed only by the private API process under a transaction-scoped platform service context.
COMMIT;
