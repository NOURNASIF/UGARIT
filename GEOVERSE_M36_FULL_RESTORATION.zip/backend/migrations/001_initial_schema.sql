-- UGARIT M16: standalone educational platform schema (no school/class entities).
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE user_profiles (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 full_name text NOT NULL CHECK (length(trim(full_name)) BETWEEN 2 AND 160),
 role text NOT NULL CHECK (role IN ('teacher','platform_admin')),
 status text NOT NULL DEFAULT 'active' CHECK (status IN ('pending','active','suspended')),
 preferred_locale text NOT NULL DEFAULT 'ar',
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE learning_resources (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 title text NOT NULL CHECK (length(trim(title)) BETWEEN 2 AND 240),
 subject text NOT NULL DEFAULT 'geography',
 grade_level text,
 resource_type text NOT NULL CHECK (resource_type IN ('lesson','map','worksheet','video','dataset','reference')),
 content_uri text,
 content_json jsonb NOT NULL DEFAULT '{}'::jsonb,
 publication_status text NOT NULL DEFAULT 'draft' CHECK (publication_status IN ('draft','review','published','archived')),
 created_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_resources_subject_grade ON learning_resources(subject,grade_level,publication_status);
CREATE TABLE audit_logs (
 id bigserial PRIMARY KEY,
 actor_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
 action text NOT NULL,
 entity_type text NOT NULL,
 entity_id text,
 request_id text,
 metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_actor_date ON audit_logs(actor_id,created_at DESC);
