-- UGARIT M16: only the platform owner can provision independent teacher accounts.
BEGIN;
DROP POLICY IF EXISTS profile_platform_create_independent_teacher ON user_profiles;
CREATE POLICY profile_platform_create_independent_teacher ON user_profiles
 FOR INSERT WITH CHECK (
  current_setting('app.user_role',true)='platform_admin'
  AND role='teacher'
  AND status='active'
 );
DROP POLICY IF EXISTS audit_platform_create_independent_teacher ON audit_logs;
CREATE POLICY audit_platform_create_independent_teacher ON audit_logs
 FOR INSERT WITH CHECK (
  current_setting('app.user_role',true)='platform_admin'
  AND actor_id=NULLIF(current_setting('app.user_id',true),'')::uuid
 );
COMMIT;
