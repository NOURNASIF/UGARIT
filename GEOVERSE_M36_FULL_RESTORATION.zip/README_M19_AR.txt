أوغاريت UGARIT — حزمة التطوير M19
الإصدار 0.1.20

ابدأ بقراءة:
1) DEVELOPMENT_LOG_M19_AR.md
2) SCHOOL_OPERATIONS_API_M19_AR.md
3) TEST_REPORT_M19_AR.txt

هذه حزمة تطوير مستقلة مشتقة من M18. لا ترفعها إلى GitHub ولا تنشرها على Netlify قبل مراجعة المستخدم.

تتطلب بوابة المدارس قبل التشغيل الحقيقي:
- PostgreSQL.
- تطبيق migrations بالترتيب الصحيح.
- تشغيل backend وإعداد DATABASE_URL وJWT_SECRET.
- ضبط CORS_ORIGINS.
- ضبط apiBaseUrl في modules/config.js وإعادة بناء index.html.

لا توجد بيانات دخول تجريبية. لا تضع مفاتيح أو كلمات مرور سرية داخل ملفات الواجهة.
