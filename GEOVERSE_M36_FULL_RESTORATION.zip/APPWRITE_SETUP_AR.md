# إعداد Appwrite + Netlify لعضوية أوغاريت 0.1

## القيم العامة المهيأة في الموقع
- Endpoint: `https://fra.cloud.appwrite.io/v1`
- Project ID: `6af092e50030484ca7e3`
- Database ID: `6af0938e003a961f1366`
- Table ID: `6af093f2003020135a3e`
- نطاق Web المسجل: `nour-ugaritgeo-school.netlify.app`

## أعمدة جدول membership_requests المطلوبة
يجب أن تتطابق المفاتيح حرفياً مع الآتي:
- `userId` — Text، Required
- `amount` — Integer، Required، Min=1، Max=1
- `currency` — Text، Required
- `status` — Text، Required
- `paymentReference` — Text، Optional
- `paymentProof` — Text، Optional (معرّف ملف Storage مستقبلاً؛ رفع الملفات لم يفعّل بعد)

الكود لا يرسل عمود `username` أو `submittedAt`، ويستخدم `$createdAt` التلقائي. قيمة الحالة الأولية ثابتة في وظيفة Netlify: `pending_review`، والسعر ثابت: 1 USD.

## صلاحيات الجدول
- اترك Row Security مفعّلاً.
- على مستوى الجدول: امنح دور `Users` صلاحية CREATE فقط إذا كان خيارها مطلوباً للتطبيقات العميلة. لا تمنح `Any` أو `Guests` أي صلاحية.
- لا تمنح `Any` أو `Users` صلاحية READ أو UPDATE أو DELETE على مستوى الجدول.
- وظيفة Netlify تنشئ الصف عبر Server SDK وتضيف صلاحية READ لصاحب الصف فقط.
- لا يملك العميل وظيفة تغيير `status`. تغيير الحالة إلى `active` أو `refunded` يجب أن يتم من الإدارة عبر لوحة Appwrite أو وظيفة إدارية موثوقة بعد التحقق اليدوي من شام كاش.

## متغيرات Netlify السرية المطلوبة
من Netlify: Site configuration > Environment variables، أضف:
- `APPWRITE_ENDPOINT` = `https://fra.cloud.appwrite.io/v1`
- `APPWRITE_PROJECT_ID` = `6af092e50030484ca7e3`
- `APPWRITE_DATABASE_ID` = `6af0938e003a961f1366`
- `APPWRITE_MEMBERSHIP_TABLE_ID` = `6af093f2003020135a3e`
- `APPWRITE_API_KEY` = مفتاح API جديد من Appwrite بصلاحية `rows.write` فقط إن كانت كافية لإصدار حسابك. لا تضع هذا المفتاح في ملفات الموقع أو المحادثة أو Git.

بعد إضافة المتغيرات، أعد نشر الموقع حتى تُحمّلها Netlify Functions.

## مسار العمل
1. الواجهة تنشئ حساب Appwrite وتفتح جلسة بريد/كلمة مرور.
2. ترسل الجلسة إلى `/.netlify/functions/create-membership-request`.
3. الوظيفة تتحقق من الجلسة عبر `/account`، وتستخرج هوية المستخدم من Appwrite، ثم تنشئ صفاً ثابت الحالة `pending_review` بسعر 1 USD.
4. يحصل المستخدم على صلاحية قراءة صفه فقط.
5. لا يُفتح الموقع حتى تصبح `status` مساوية `active`.

## حدود النسخة الحالية
- لم يُختبر الاتصال بخدمة Appwrite الحية من بيئة البناء.
- لم يُنشأ API Key ولم تُضف متغيرات Netlify؛ يجب على مالك الحساب القيام بذلك داخل لوحة التحكم.
- لم يُفعّل رفع صورة إثبات الدفع إلى Storage بعد، رغم وجود عمود مخصص له.
- لا يوجد تكامل آلي مع شام كاش ولا رد أموال آلي. مراجعة التحويل وتحديث الحالة يدويان.
- لا تنشر بوابة دفع حقيقية قبل اختبار التسجيل، قراءة الصف بصلاحية صاحبه، منع قراءة صفوف الآخرين، ومراجعة وظيفة الإدارة.


## دخول صاحب المنصة (UGARIT Owner Portal)
بعد نشر هذه الحزمة، أضف المتغيرات التالية في Netlify > Site configuration > Environment variables. لا تضعها في ملفات الموقع ولا ترسل كلمة المرور في المحادثات:
- `UGARIT_ADMIN_USERNAME` = اسم المستخدم الإداري الحالي الذي سبق ضبطه في Netlify؛ لا تغيّره بسبب اسم زر الواجهة.
- `UGARIT_ADMIN_PASSWORD` = كلمة مرور إدارية قوية تختارها بنفسك (16 محرفاً على الأقل).
- `UGARIT_ADMIN_SESSION_SECRET` = قيمة عشوائية طويلة لا تقل عن 32 محرفاً.
- `APPWRITE_ENDPOINT` = `https://fra.cloud.appwrite.io/v1`
- `APPWRITE_PROJECT_ID` = معرّف مشروع Appwrite.
- `APPWRITE_API_KEY` = مفتاح API سري بصلاحيات قراءة صفوف جدول العضويات فقط قدر الإمكان؛ لا تستخدم مفتاحاً عاماً ولا تضعه في ملفات الواجهة.
- `APPWRITE_DATABASE_ID` = معرّف قاعدة البيانات.
- `APPWRITE_MEMBERSHIP_TABLE_ID` = معرّف جدول العضويات.
بعد إضافة المتغيرات يلزم إعادة نشر الموقع. جلسة المدير صالحة 8 ساعات وتستخدم Cookie من نوع HttpOnly/Secure. تعرض اللوحة صفوف جدول العضويات فقط ولا تتحقق آلياً من تحويل شام كاش.
