/* GeoVerse M31 — privacy-conscious local teaching analytics. */
(function initTeacherAnalytics(){
 'use strict';
 const host=document.getElementById('teacherAnalyticsHost');
 if(!host)return;
 const grade=document.getElementById('teacherAnalyticsGrade');
 const refresh=document.getElementById('teacherAnalyticsRefresh');
 const exportBtn=document.getElementById('teacherAnalyticsExport');
 const metrics=document.getElementById('teacherAnalyticsMetrics');
 const skillsHost=document.getElementById('teacherAnalyticsSkills');
 const topicsHost=document.getElementById('teacherAnalyticsTopics');
 const status=document.getElementById('teacherAnalyticsStatus');
 const labels={spatial:'المعرفة المكانية',maps:'قراءة الخرائط والإحداثيات',climate:'المناخ والبيئة',population:'السكان والتنمية',economy:'الجغرافيا الاقتصادية',data:'تحليل البيانات الجغرافية',resources:'الموارد والاستدامة'};
 const read=()=>{try{const x=JSON.parse(localStorage.getItem('gq_attempts')||'[]');return Array.isArray(x)?x.filter(a=>a&&Number.isFinite(Number(a.grade))&&Number.isFinite(Number(a.percent))):[]}catch(_){return []}};
 const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=String(txt);return n};
 let current=[];
 function render(){const all=read(),g=grade.value;current=all.filter(a=>g==='all'||Number(a.grade)===Number(g));metrics.replaceChildren();skillsHost.replaceChildren();topicsHost.replaceChildren();
  const avg=current.length?Math.round(current.reduce((s,a)=>s+Number(a.percent),0)/current.length):0;
  [[current.length,'محاولات مسجلة'],[avg+'٪','متوسط النتائج'],[current.length?Math.max(...current.map(a=>Number(a.percent)))+'٪':'—','أفضل نتيجة'],[new Set(current.map(a=>Number(a.grade))).size,'صفوف ممثلة']].forEach(([v,l])=>{const card=el('div','teacher-dash-metric');card.append(el('strong','',v),el('span','',l));metrics.append(card)});
  const totals={};current.forEach(a=>(Array.isArray(a.skills)?a.skills:[]).forEach(s=>{if(!s||!labels[s.skill]||!Number.isFinite(Number(s.total))||Number(s.total)<=0)return;const row=totals[s.skill]||(totals[s.skill]={correct:0,total:0,attempts:0});row.correct+=Number(s.correct)||0;row.total+=Number(s.total)||0;row.attempts++}));
  const skillRows=Object.entries(totals).map(([key,v])=>({key,label:labels[key],...v,percent:Math.round(v.correct/v.total*100)})).sort((a,b)=>a.percent-b.percent);
  if(!skillRows.length)skillsHost.append(el('p','map-note','لا توجد بيانات مهارية كافية في المحاولات المحلية بعد.'));
  skillRows.forEach(s=>{const row=el('div','info-row');const head=el('div','',`${s.label} — ${s.percent}٪`);const detail=el('p','map-note',`${s.correct} إجابة صحيحة من ${s.total} عبر ${s.attempts} تجميعات مهارية.`);const bar=el('div','skill-bar');const fill=el('span');fill.style.width=s.percent+'%';bar.append(fill);const advice=el('small','',s.total<5?'عينة محدودة؛ اجمع مزيداً من الإجابات قبل الاستنتاج.':s.percent<60?'أولوية دعم مقترحة.':s.percent<80?'تحتاج إلى تعزيز وتطبيق.':'مؤشر أداء جيد في البيانات المتاحة.');row.append(head,bar,detail,advice);skillsHost.append(row)});
  const topics={};current.forEach(a=>(Array.isArray(a.topics)?a.topics:[]).forEach(t=>{if(!t||!t.topic)return;const v=topics[t.topic]||(topics[t.topic]={correct:0,total:0});v.correct+=Number(t.correct)||0;v.total+=Number(t.total)||0}));
  const topicRows=Object.entries(topics).sort((a,b)=>(a[1].correct/a[1].total)-(b[1].correct/b[1].total));
  if(!topicRows.length)topicsHost.append(el('p','map-note','لا توجد بيانات حسب الموضوع في السجل الحالي.'));
  topicRows.forEach(([name,v])=>topicsHost.append(el('div','learning-memory-row',`${name}: ${Math.round(v.correct/v.total*100)}٪ (${v.correct}/${v.total})`)));
  status.textContent=current.length?'البيانات المعروضة مأخوذة من سجل الاختبارات المحلي على هذا الجهاز فقط؛ لا تمثل قائمة طلاب ولا مزامنة مدرسية.':'لا توجد محاولات مطابقة للصف المحدد على هذا الجهاز.';
 }
 function csv(){const rows=[['المهارة','الصحيحة','الإجمالي','النسبة','عدد التجميعات']];const sums={};current.forEach(a=>(a.skills||[]).forEach(s=>{if(!s||!labels[s.skill])return;const x=sums[s.skill]||(sums[s.skill]={c:0,t:0,n:0});x.c+=Number(s.correct)||0;x.t+=Number(s.total)||0;x.n++}));Object.entries(sums).forEach(([k,v])=>rows.push([labels[k],v.c,v.t,Math.round(v.c/v.t*100)+'%',v.n]));const csvText='\uFEFF'+rows.map(r=>r.map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\n');const url=URL.createObjectURL(new Blob([csvText],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='geoverse-teacher-local-analytics.csv';a.click();URL.revokeObjectURL(url)}
 refresh.addEventListener('click',render);grade.addEventListener('change',render);exportBtn.addEventListener('click',csv);window.addEventListener('storage',e=>{if(e.key==='gq_attempts')render()});render();
})();
