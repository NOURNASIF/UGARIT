import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const start = source.indexOf('const tutorKnowledge=[');
const end = source.indexOf('function tutorAddMessage', start);
assert.ok(start >= 0 && end > start, 'tutor knowledge and answer functions must exist');
const block = source.slice(start, end) + '\n globalThis.__tutor = {tutorBuildAnswer, tutorCompareAnswer, findTutorTopic};';
let currentMode = 'compare';
const sandbox = {
  document: { getElementById(id) { return { value: id === 'tutorMode' ? currentMode : 'school' }; } }
};
vm.createContext(sandbox);
vm.runInContext(block, sandbox);
const tutor = sandbox.__tutor;

test('compares weather and climate in a structured table', () => {
  const result = tutor.tutorBuildAnswer('قارن بين الطقس والمناخ');
  assert.match(result.title, /الطقس والمناخ/);
  assert.match(result.html, /وجه المقارنة/);
  assert.match(result.html, /المدة الزمنية/);
});

test('compares two distinct geography concepts from the local knowledge base', () => {
  const result = tutor.tutorBuildAnswer('قارن بين الكثافة السكانية والهجرة');
  assert.match(result.title, /الكثافة السكانية/);
  assert.match(result.title, /الهجرة السكانية/);
  assert.match(result.html, /التعريف/);
});

test('asks for two concepts when a comparison request is incomplete', () => {
  const result = tutor.tutorBuildAnswer('قارن بين التضاريس');
  assert.match(result.title, /حدد المفهومين/);
});

test('recognizes new GIS and remote-sensing topics', () => {
  currentMode = 'explain';
  assert.match(tutor.tutorBuildAnswer('اشرح نظم المعلومات الجغرافية').title, /نظم المعلومات الجغرافية/);
  assert.match(tutor.tutorBuildAnswer('اشرح الاستشعار عن بعد').title, /الاستشعار عن بُعد/);
});

test('quiz mode provides a collapsible model-guidance answer after the question', () => {
  currentMode = 'quiz';
  const result = tutor.tutorBuildAnswer('اشرح الكثافة السكانية');
  assert.match(result.html, /سؤال تحقق من الفهم/);
  assert.match(result.html, /<details/);
  assert.match(result.html, /إجابة إرشادية مختصرة/);
});
