import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const app=readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const sw=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
test('map lab exposes grade, topic, and skill controls for printable worksheets',()=>{
 assert.match(html,/id="mapWorksheetGrade"/); assert.match(html,/id="mapWorksheetTopic"/); assert.match(html,/id="mapWorksheetSkill"/);
 assert.match(html,/إنشاء وطباعة ورقة العمل/);
});
test('worksheet generator has six distinct geography topic templates',()=>{
 const topics=['locations','coordinates','scale','landforms','human','mapreading'];
 for(const topic of topics) assert.match(app,new RegExp(topic+':\\{title:'));
 assert.match(app,/function buildMapWorksheetHtml\(\)/);
});
test('worksheet output escapes user-visible values and warns against official exam use',()=>{
 assert.match(app,/const escape=value=>String\(value\)\.replace/);
 assert.match(app,/ليست اختباراً وزارياً/);
 assert.match(app,/مراجعة المعلم/);
});
test('M26 uses a fresh service worker cache key',()=>assert.match(sw,/geoverse-shell-v0\.1\.37-m36/));
