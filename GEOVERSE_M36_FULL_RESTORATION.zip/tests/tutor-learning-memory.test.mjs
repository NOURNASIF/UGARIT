import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');

test('learning memory is versioned, local, bounded, and resilient to malformed storage', () => {
  assert.match(app, /const LEARNING_MEMORY_KEY='gq_learning_memory_v1'/);
  assert.match(app, /value\.version!==1\|\|!Array\.isArray\(value\.entries\)/);
  assert.match(app, /slice\(-200\)/);
  assert.match(app, /catch\(e\)\{return \{version:1,entries:\[\]\}\}/);
});

test('opening lessons and self-rating update the learning record', () => {
  assert.match(app, /recordLessonStudy\(activeLesson\)/);
  assert.match(app, /recordLessonSelfRating\(activeLesson,Number\(v\)\)/);
  assert.match(app, /studyCount:\(existing\?\.studyCount\|\|0\)\+1/);
});

test('lesson quiz results are stored and spaced review intervals reflect performance', () => {
  assert.match(app, /recordLessonQuizResult\(percent\)/);
  assert.match(app, /percent<60\?'low':percent<80\?'medium':'high'/);
  assert.match(app, /performance==='low'\?1:performance==='medium'\?3:7/);
  assert.match(app, /recordLessonQuizResult\(percent\)/);
});

test('review recommendations are filtered to the active grade and provide a lesson action', () => {
  assert.match(app, /entries\.filter\(x=>x\.grade===Number\(currentGrade\)\)/);
  assert.match(app, /x\.nextReviewAt/);
  assert.match(app, /textContent='راجع الدرس'/);
  assert.match(app, /select\.dispatchEvent\(new Event\('change'\)\)/);
});

test('learning memory is included in export, full backup, restore validation, and clear-progress action', () => {
  assert.match(app, /learningMemory:readLearningMemory\(\)/);
  assert.match(app, /'gq_learning_memory_v1'/);
  assert.match(app, /ذاكرة التعلم في النسخة الاحتياطية غير صالحة/);
  assert.match(app, /localStorage\.removeItem\(LEARNING_MEMORY_KEY\)/);
});

test('tutor UI exposes the learning memory and responsive review rows', () => {
  assert.match(html, /id="tutorLearningMemory"/);
  assert.match(html, /ذاكرة الدروس محفوظة أيضاً داخل بطاقة المعلم الذكي/);
  assert.match(css, /\.tutor-learning-memory/);
  assert.match(css, /@media\(max-width:520px\)\{\.learning-memory-row/);
});
