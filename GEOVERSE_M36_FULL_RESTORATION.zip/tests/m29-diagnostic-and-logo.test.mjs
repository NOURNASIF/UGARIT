import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../',import.meta.url);
const html=fs.readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const diagnostic=fs.readFileSync(new URL('../src/js/diagnostic.js',import.meta.url),'utf8');
const build=fs.readFileSync(new URL('../src/build.py',import.meta.url),'utf8');
const sw=fs.readFileSync(new URL('../sw.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('M29 diagnostic has five geography questions, feedback, and a restart action',()=>{
 assert.match(html,/id="diagnosticAssessment"/);assert.match(html,/id="diagnosticStart"/);assert.match(diagnostic,/const questions=\[/);assert.equal((diagnostic.match(/skill:'/g)||[]).length,5);assert.match(diagnostic,/renderResult/);assert.match(diagnostic,/إعادة التقييم/);
});
test('diagnostic labels its score as indicative and stores no account credentials',()=>{
 assert.match(diagnostic,/لا تكفي وحدها لتحديد مستواك الدراسي/);assert.match(diagnostic,/geoverse_diagnostic_m29/);assert.doesNotMatch(diagnostic,/password|email|APPWRITE/i);
});
test('M29 logo assets referenced by entry, hero, and PWA exist at the deploy root',()=>{
 for(const file of ['geoverse-logo.png','geoverse-icon-192.png','geoverse-icon-512.png','geoverse-mark.svg'])assert.ok(fs.existsSync(new URL('../'+file,import.meta.url)),file+' exists');
 assert.match(html,/src="geoverse-logo\.png"/);assert.match(html,/src="geoverse-icon-512\.png"/);assert.match(sw,/\.\/geoverse-logo\.png/);assert.match(sw,/\.\/geoverse-icon-512\.png/);
});
test('M29 build inlines the diagnostic module and updates app cache version',()=>{
 assert.match(build,/diagnostic\.js/);assert.equal(pkg.version,'0.1.37');assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});
