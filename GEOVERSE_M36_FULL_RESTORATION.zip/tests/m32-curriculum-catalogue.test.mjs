import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const data = readFileSync(new URL('../src/js/data.js', import.meta.url), 'utf8');
const app = readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const curriculum = JSON.parse(vm.runInNewContext(`${data}\nJSON.stringify(curriculumLessons.map(x=>({id:x.id,grade:x.catalogue.grade,unit:x.catalogue.unit,objectives:x.catalogue.objectives,concepts:x.catalogue.concepts,sourceLevel:x.catalogue.sourceLevel,verification:x.catalogue.verification})))`));

test('M32 adds structured catalogue metadata without promoting unverified sources', () => {
  assert.ok(curriculum.length >= 1);
  assert.ok(curriculum.every(x => x.grade >= 1 && x.grade <= 12));
  assert.ok(curriculum.every(x => x.unit && Array.isArray(x.objectives) && Array.isArray(x.concepts)));
  assert.ok(curriculum.every(x => x.sourceLevel === 'secondary_index_only'));
});

test('catalogue UI is grade scoped and exposes unit and verification filters', () => {
  for (const id of ['curriculumCatalogPanel','curriculumCatalogList','curriculumCatalogCount','curriculumUnitFilter','curriculumSourceFilter']) assert.match(html, new RegExp(`id="${id}"`));
  assert.match(app, /function renderCurriculumCatalog\(/);
  assert.match(app, /includes\(Number\(currentGrade\)\)/);
  assert.match(app, /فهرسة أولية — بانتظار فحص الكتاب/);
});

test('lesson search includes unit, objectives and concepts; catalogue remains responsive', () => {
  assert.match(app, /\.\.\(l\.objectives\|\|\[\]\)/);
  assert.match(app, /\.\.\(l\.vocab\|\|\[\]\)/);
  assert.match(css, /@media\(max-width:520px\)\{\.curriculum-catalog-item/);
  assert.match(html, /لا تظهر حالة «موثق صفحةً بصفحة» إلا عند وجود مرجع صفحات موثق/);
});
