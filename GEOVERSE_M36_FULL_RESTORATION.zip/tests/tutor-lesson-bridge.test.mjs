import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');

test('smart tutor exposes a lesson selector and linked lesson actions', () => {
  for (const id of ['tutorLessonSelect', 'tutorLessonDetail', 'tutorLessonExplain', 'tutorLessonSummarize', 'tutorLessonQuiz', 'tutorLessonQuizHost']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
  assert.match(app, /function renderTutorLessonPicker\(\)/);
  assert.match(app, /function appendTutorLessonResponse\(mode\)/);
});

test('lesson picker uses only lessons assigned to the currently selected grade', () => {
  assert.match(app, /function getTutorGradeLessons\(\)\{return getAllLessons\(\)\.filter\(lesson=>lesson&&Array\.isArray\(lesson\.grades\)&&lesson\.grades\.includes\(Number\(currentGrade\)\)\)/);
  assert.match(app, /renderTutorLessonPicker\(\);if\(typeof renderTutorLearningMemory==='function'\)renderTutorLearningMemory\(\)\}\);/);
});

test('lesson quiz uses the same grade and exact lesson topic, with validated answer data', () => {
  assert.match(app, /q\.topic===topic/);
  assert.match(app, /q\.grades\.includes\(Number\(currentGrade\)\)/);
  assert.match(app, /Number\.isInteger\(q\.c\)&&q\.c>=0&&q\.c<q\.a\.length/);
  assert.match(app, /لا توجد أسئلة مرتبطة مباشرة بموضوع هذا الدرس/);
});

test('lesson quiz provides feedback, explanations, score, and retry', () => {
  assert.match(app, /function submitTutorLessonAnswer\(choice\)/);
  assert.match(app, /q\.why\|\|\('الإجابة الصحيحة:/);
  assert.match(app, /نتيجة تدريب الدرس/);
  assert.match(app, /إعادة التدريب/);
});

test('lesson bridge has responsive-friendly wrapping and disabled action states', () => {
  assert.match(css, /\.tutor-lesson-actions\{display:flex;gap:7px;flex-wrap:wrap/);
  assert.match(css, /\.tutor-lesson-actions button:disabled/);
});
