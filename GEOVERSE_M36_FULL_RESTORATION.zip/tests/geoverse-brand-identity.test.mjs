import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const html = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const manifest = JSON.parse(readFileSync(new URL('../manifest.webmanifest', import.meta.url), 'utf8'));
const sw = readFileSync(new URL('../sw.js', import.meta.url), 'utf8');
const config = readFileSync(new URL('../modules/appwrite-config.js', import.meta.url), 'utf8');

test('GeoVerse Arabic and English names are the active visible identity', () => {
  assert.match(html, /GeoVerse \| جيو فيرس/);
  assert.match(html, /<h1>جيو فيرس<\/h1>/);
  assert.match(html, /alt="GeoVerse — جيو فيرس"/);
  assert.doesNotMatch(html, /أوغاريت \| منصة/);
});

test('PWA identity changes without changing its app id, origin scope, or start route', () => {
  assert.equal(manifest.id, './');
  assert.equal(manifest.start_url, './');
  assert.equal(manifest.scope, './');
  assert.equal(manifest.short_name, 'جيو فيرس');
  assert.equal(manifest.name, 'GeoVerse | جيو فيرس — منصة الجغرافيا التعليمية');
});

test('new brand assets are precached and exist in the deploy root', () => {
  for (const file of ['geoverse-mark.svg', 'geoverse-logo.png', 'geoverse-icon-192.png', 'geoverse-icon-512.png']) {
    assert.ok(existsSync(new URL(`../${file}`, import.meta.url)), `${file} exists`);
    assert.ok(sw.includes(`./${file}`), `${file} is precached`);
  }
  assert.match(sw, /geoverse-shell-v0\.1\.37-m36/);
});

test('Appwrite configuration and integration identifiers remain intact', () => {
  assert.match(config, /UGARIT_APPWRITE_CONFIG/);
  assert.match(config, /endpoint: 'https:\/\/fra\.cloud\.appwrite\.io\/v1'/);
  assert.match(config, /projectId: '6af092e50030484ca7e3'/);
});
