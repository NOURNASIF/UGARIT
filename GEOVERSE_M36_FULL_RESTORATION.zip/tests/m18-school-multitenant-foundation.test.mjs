import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const server=read('backend/src/server.js');
const security=read('backend/src/school-security.js');
const migration=read('backend/migrations/006_school_tenant_core.sql');
const operations=read('backend/migrations/007_school_operations_tenant.sql');
const portal=read('src/js/school-portal.js');
const html=read('src/index.src.html');

test('M18 has independent school provisioning, one-time activation, login and session endpoints',()=>{
 for(const route of ["/api/v1/admin/schools","/api/v1/school/activate","/api/v1/school/auth/login","/api/v1/school/me","/api/v1/school/dashboard","/api/v1/school/users"])assert.ok(server.includes(route),`missing ${route}`);
 assert.match(server,/roles\('platform_admin'\)/);
 assert.match(server,/school_activation_keys/);
 assert.match(server,/consumed_at IS NULL/);
});
test('school login uses separate token audience and server-side active identity checks',()=>{
 assert.match(security,/aud:'ugarit-school'/);
 assert.match(server,/claims\.aud!=='ugarit-school'/);
 assert.match(server,/organization_status!=='active'/);
});
test('tenant core migration scopes organizations and school users with RLS',()=>{
 for(const token of ['school_organizations','school_activation_keys','school_users','school_auth_credentials','school_audit_logs','ENABLE ROW LEVEL SECURITY','app.school_org_id','school_org_platform_admin_manage'])assert.ok(migration.includes(token),`missing ${token}`);
});
test('school operations schema applies organization isolation to operational records',()=>{
 for(const table of ['school_academic_years','school_classes','school_students','school_attendance_records','school_assignments','school_lesson_plans','school_assessments','school_assessment_results'])assert.ok(operations.includes(table),`missing ${table}`);
 assert.match(operations,/school_org_id/);
});
test('school login UI remains disabled until a server API base URL is configured',()=>{
 assert.match(portal,/const apiReady=Boolean\(apiBase\)/);
 assert.match(portal,/setFormEnabled\(apiReady\)/);
 assert.match(portal,/sessionStorage|accessToken=''/);
 assert.match(html,/id="schoolLoginSlug"/);
 assert.match(html,/id="schoolLiveDashboard" hidden/);
});
test('school users can only be created by a school administrator as teacher or staff',()=>{
 assert.match(server,/u\.role!=='school_admin'/);
 assert.match(server,/\['school_teacher','school_staff'\]\.includes\(role\)/);
});
