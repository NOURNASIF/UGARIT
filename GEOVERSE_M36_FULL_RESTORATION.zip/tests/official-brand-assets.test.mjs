import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';
const root = new URL('../', import.meta.url);
const file = name => join(root.pathname, name);
test('M23 uses the exact user-approved GeoVerse logo artwork', async () => {
  const installed = await readFile(file('geoverse-logo.png'));
  assert.equal(installed.length, 880865);
  assert.equal(installed.readUInt32BE(16), 1536);
  assert.equal(installed.readUInt32BE(20), 1024);
});
test('GeoVerse app icons are generated at supported square dimensions', async () => {
  for (const [name, expected] of [['geoverse-icon-192.png',192],['geoverse-icon-512.png',512]]) {
    const b = await readFile(file(name));
    assert.equal(b.readUInt32BE(16), expected);
    assert.equal(b.readUInt32BE(20), expected);
  }
});
test('manifest declares the new release and approved brand icon assets', async () => {
  const m = JSON.parse(await readFile(file('manifest.webmanifest'),'utf8'));
  assert.equal(m.version, '0.1.37');
  assert.ok(m.icons.some(x => x.src === './geoverse-icon-192.png'));
  assert.ok(m.icons.some(x => x.src === './geoverse-icon-512.png'));
});
test('service worker cache key is advanced for M36 release candidate and brand assets', async () => {
  const sw = await readFile(file('sw.js'),'utf8');
  assert.match(sw, /geoverse-shell-v0\.1\.37-m36/);
  assert.match(sw, /\.\/geoverse-logo\.png/);
  assert.match(sw, /\.\/geoverse-icon-512\.png/);
});
test('browser favicon points to the approved GeoVerse emblem icon', async () => {
  const html = await readFile(file('src/index.src.html'),'utf8');
  assert.match(html, /rel="icon" type="image\/png" sizes="192x192" href="geoverse-icon-192\.png"/);
  assert.doesNotMatch(html, /rel="icon" type="image\/svg\+xml"/);
});
