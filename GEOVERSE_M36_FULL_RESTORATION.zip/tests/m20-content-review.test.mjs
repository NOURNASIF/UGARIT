import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const app = readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const auth = readFileSync(new URL('../modules/teacher-auth.js', import.meta.url), 'utf8');

test('teacher-authored questions default to pending review', () => {
  assert.match(app, /reviewStatus:'pending_review'/);
  assert.match(app, /حُفظ السؤال كمسودة بانتظار مراجعة مسؤول GeoVerse/);
});
test('only approved teacher questions enter the student question bank', () => {
  assert.match(app, /getTeacherBank\(\)\.filter\(q=>q&&q\.reviewStatus==='approved'\)/);
  assert.doesNotMatch(app, /bank\.push\(item\);saveTeacherBank\(bank\);questionBank\.push\(item\)/);
});
test('only approved custom lessons enter student lesson library', () => {
  assert.match(app, /getCustomLessons\(\)\.filter\(l=>l\.reviewStatus==='approved'\)/);
});
test('lesson and question imports are held for review', () => {
  assert.match(app, /reviewStatus:'pending_review'/);
  assert.match(app, /saveCustomLessons\(merged\)/);
  assert.match(app, /const fresh=arr\.filter/);
  assert.match(app, /saveTeacherBank\(old\.concat\(fresh\)\)/);
});
test('approval controls require platform administrator role', () => {
  assert.match(app, /getUser\?\.\(\)\?\.role==='platform_admin'/);
  assert.match(app, /if\(!isPlatformContentReviewer\(\)\)return/);
  assert.match(auth, /teacherRoles = \['teacher', 'platform_admin'\]/);
});
test('moderation interface clearly warns that central approval is not yet enabled', () => {
  assert.match(html, /id="contentReviewQueue"/);
  assert.match(html, /الاعتماد المركزي الآمن بين الأجهزة يتطلب API وقاعدة بيانات وصلاحيات خادمية/);
});
