import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';

const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const sourceHtml = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const adminModule = readFileSync(new URL('../modules/admin-portal.js', import.meta.url), 'utf8');

test('owner entry is clearly separate from student registration and login', () => {
  assert.match(html, /id="tabRegister"[^>]*>إنشاء حساب واشتراك/);
  assert.match(html, /id="tabLogin"[^>]*>تسجيل الدخول/);
  assert.match(html, /id="tabAdmin"[^>]*>دخول Admin/);
});

test('admin form is wired to the current module and has a safe missing-script fallback', () => {
  assert.match(html, /admin-portal\.js\?v=0\.1\.12/);
  assert.match(html, /UGARIT_ADMIN_HANDLER_READY/);
  assert.match(adminModule, /UGARIT_ADMIN_HANDLER_READY = true/);
  assert.match(html, /تعذر تحميل نظام دخول المدير/);
});

test('successful owner login verifies the session and unlocks without redirecting or restoring on load', () => {
  assert.match(adminModule, /await api\('session'\)/);
  assert.match(adminModule, /unlock\(\)/);
  assert.match(adminModule, /api\('logout'\)\.catch/);
  assert.doesNotMatch(adminModule, /api\('session'\)\.then/);
  assert.doesNotMatch(adminModule, /window\.location\.replace/);
});

test('source template and service worker are cache-busted for this release', () => {
  assert.match(sourceHtml, /admin-portal\.js\?v=0\.1\.12/);
  assert.match(sourceHtml, /Fail closed: if the admin module did not load/);
  assert.match(sourceHtml, /تعذر تحميل نظام دخول المدير/);
  assert.match(sourceHtml, /id=\"ugaritAdminDock\"/);
  const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
  assert.match(css, /\.admin-dock\[hidden\]\{display:none!important\}/);
  const sw = readFileSync(new URL('../sw.js', import.meta.url), 'utf8');
  assert.match(sw, /geoverse-shell-v0\.1\.37-m36/);
});
