import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const atlas=readFileSync(new URL('../src/js/atlas.js',import.meta.url),'utf8');
const sw=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
test('M26 adds a dedicated governorate comparison area to the Syrian atlas',()=>{
 assert.match(html,/id="atlasCompare"/);
 assert.match(atlas,/function initComparison\(\)/);
 assert.match(atlas,/atlasCompareA/); assert.match(atlas,/atlasCompareB/);
});
test('comparison uses existing descriptive atlas fields and prompts geographic analysis',()=>{
 assert.match(atlas,/الموقع والسمات/); assert.match(atlas,/الأنشطة/);
 assert.match(atlas,/ما أوجه التشابه والاختلاف/);
 assert.match(atlas,/اختر محافظتين مختلفتين/);
});
test('comparison offers printing and M26 cache version is unique',()=>{
 assert.match(atlas,/atlasComparePrint/);
 assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});

test('M27 builds distinct comparison options without duplicate selected values',()=>{
 assert.match(atlas,/const options=\(selected\)=>GOV\.map/);
 assert.doesNotMatch(atlas,/opts\.replace\('value=/);
 assert.match(atlas,/options\(0\)/); assert.match(atlas,/options\(2\)/);
});
test('M27 explains whether the selected governorates share a region',()=>{
 assert.match(atlas,/خلاصة مكانية/); assert.match(atlas,/تقع المحافظتان ضمن الإقليم نفسه/);
 assert.match(atlas,/تنتمي المحافظتان إلى إقليمين مختلفين/);
});
