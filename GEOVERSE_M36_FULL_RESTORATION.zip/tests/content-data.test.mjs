import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const source = readFileSync(new URL('../src/js/data.js', import.meta.url), 'utf8');
const audit = JSON.parse(vm.runInNewContext(`${source}\nJSON.stringify({
  lessonCount: lessons.length,
  questionCount: questionBank.length,
  lessons: lessons.map(({title, grades, body, desc}) => ({title, grades, body, desc})),
  questions: questionBank.map(({q, a, c, grades, source, review, provenance}) => ({q, a, c, grades, source, review, provenance}))
})`));

test('geography lesson records have required content and valid grade ranges', () => {
  assert.equal(audit.lessonCount, 24);
  for (const lesson of audit.lessons) {
    assert.ok(lesson.title?.trim());
    assert.ok(lesson.desc?.trim());
    assert.ok(lesson.body?.trim());
    assert.ok(Array.isArray(lesson.grades) && lesson.grades.length > 0);
    assert.ok(lesson.grades.every(grade => Number.isInteger(grade) && grade >= 1 && grade <= 12));
  }
});

test('question bank records have valid answers, grade ranges, and provenance labels', () => {
  assert.equal(audit.questionCount, 186);
  for (const question of audit.questions) {
    assert.ok(question.q?.trim());
    assert.ok(Array.isArray(question.a) && question.a.length >= 2);
    assert.ok(Number.isInteger(question.c) && question.c >= 0 && question.c < question.a.length);
    assert.ok(Array.isArray(question.grades) && question.grades.length > 0);
    assert.ok(question.grades.every(grade => Number.isInteger(grade) && grade >= 1 && grade <= 12));
    assert.ok(question.source && question.review && question.provenance);
  }
});

test('all twelve grades have at least one lesson and one question available', () => {
  for (let grade = 1; grade <= 12; grade++) {
    assert.ok(audit.lessons.some(item => item.grades.includes(grade)), `no lesson for grade ${grade}`);
    assert.ok(audit.questions.some(item => item.grades.includes(grade)), `no question for grade ${grade}`);
  }
});
