import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const dataSource = readFileSync(new URL('../src/js/data.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const snapshot = JSON.parse(vm.runInNewContext(`${dataSource}\nJSON.stringify({
  lessons: lessons.map(({title, grades, classification, verificationStatus, sourceStatus}) => ({title, grades, classification, verificationStatus, sourceStatus})),
  questions: questionBank.map(({grades}) => ({grades})),
  curriculum: curriculumLessons.map(({title, grades, classification, verificationStatus, sourceStatus}) => ({title, grades, classification, verificationStatus, sourceStatus}))
})`));

test('coverage dashboard clearly distinguishes available content from official curriculum completion', () => {
  assert.match(html, /id="curriculumCoverageDashboard"/);
  assert.match(html, /لا يعني اكتمال المنهاج الرسمي/);
  assert.match(html, /فحص الطبعة والصفحات والمصادر/);
});

test('coverage data contains lesson and question counts for all twelve grades', () => {
  for (let grade = 1; grade <= 12; grade++) {
    assert.ok(snapshot.lessons.some(x => x.grades.includes(grade)), `missing lesson for grade ${grade}`);
    assert.ok(snapshot.questions.some(x => x.grades.includes(grade)), `missing question for grade ${grade}`);
  }
});

test('curriculum-indexed content is explicitly distinguishable from enrichment content', () => {
  assert.ok(snapshot.curriculum.length > 0);
  assert.ok(snapshot.curriculum.every(x => Array.isArray(x.grades) && x.grades.length));
  assert.ok(snapshot.curriculum.every(x => x.classification || x.verificationStatus || x.sourceStatus));
});
