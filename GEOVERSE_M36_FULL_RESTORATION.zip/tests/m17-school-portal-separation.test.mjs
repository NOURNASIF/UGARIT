import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const html=fs.readFileSync(path.join(root,'src/index.src.html'),'utf8');
const app=fs.readFileSync(path.join(root,'src/js/app.js'),'utf8');
const portal=fs.readFileSync(path.join(root,'src/js/school-portal.js'),'utf8');
const build=fs.readFileSync(path.join(root,'src/build.py'),'utf8');
const legacy=path.join(root,'school/legacy');
test('M17 adds a distinct school portal navigation and dashboard view',()=>{
 assert.match(html,/data-view="school"[^>]*>.*?بوابة المدارس/s);
 assert.match(html,/id="view-school"/);
 assert.match(html,/id="schoolDashboardPreview"/);
 assert.match(app,/school:'بوابة المدارس'/);
});
test('school access remains fail-closed until school keys and server authentication are implemented',()=>{
 assert.match(html,/id="schoolAccessGate"/);
 assert.match(html,/id="schoolLoginSlug"/);
 assert.match(html,/id="schoolLiveDashboard" hidden/);
 assert.match(portal,/authEnabled:apiReady/);
 assert.match(portal,/setFormEnabled\(apiReady\)/);
 assert.match(portal,/addEventListener\('submit',login/);
 assert.match(portal,/fetch\(/);
 assert.doesNotMatch(portal,/localStorage\.setItem|sessionStorage\.setItem/);
});
test('previous school administration and operations source files are preserved separately',()=>{
 for(const f of ['frontend/modules/auth.js','frontend/modules/classroom.js','frontend/modules/admin-classroom.js','frontend/modules/institution.js','frontend/js/teacher-operations.js','backend/server-M15.js','backend/001_initial_schema.sql','backend/002_auth_rbac_rls.sql','backend/003_class_assessment_reporting.sql','backend/004_classroom_administration.sql']) assert.ok(fs.existsSync(path.join(legacy,f)),`missing ${f}`);
});
test('school portal helper is included by the production build process',()=>{
 assert.match(build,/school-portal\.js/);
 assert.match(build,/id="view-school"/);
});
test('student and teacher entry points remain separate from the school portal',()=>{
 assert.match(html,/data-view="teacher"/);
 assert.match(html,/data-view="tutor"/);
 assert.match(html,/id="view-teacher"/);
 assert.match(html,/id="view-tutor"/);
 assert.match(html,/id="view-school"/);
});
