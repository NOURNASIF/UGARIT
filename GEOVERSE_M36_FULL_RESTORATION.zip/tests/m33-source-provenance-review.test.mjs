import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const app=readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../manifest.webmanifest',import.meta.url),'utf8'));

test('M33 lesson editor captures provenance metadata without claiming verification',()=>{
 for(const id of ['tlSourceType','tlBookTitle','tlEdition','tlPublisher','tlPages','tlSourceUrl']) assert.match(html,new RegExp(`id=\"${id}\"`));
 assert.match(html,/لا تعني تعبئة الحقول أن المصدر قد تم التحقق منه/);
 assert.match(app,/sourceMetadata:\{sourceType:/);
 assert.match(app,/يجب أن يبدأ رابط المصدر بـ https/);
});
test('M33 review queue displays provenance and supports explicit moderation outcomes',()=>{
 assert.match(app,/function setLessonReviewStatus\(id,status,note=''/);
 assert.match(app,/\['approved','needs_revision','rejected'\]/);
 assert.match(app,/item\.sourceMetadata\|\|\{\}/);
 assert.match(app,/reviewedBy:/);
 assert.match(app,/ملاحظة المراجع/);
 assert.match(app,/إرجاع للتعديل/);
 assert.match(app,/اعتماد وإتاحة محلية/);
});
test('M33 remains local-only and increments app version',()=>{
 assert.match(html,/قرارات المراجعة وسجلها محفوظان على هذا الجهاز فقط/);
 assert.equal(manifest.version,'0.1.37');
 assert.match(readFileSync(new URL('../sw.js',import.meta.url),'utf8'),/v0\.1\.37-m36/);
 assert.match(app,/if\(!isPlatformContentReviewer\(\)\)return/);
});
