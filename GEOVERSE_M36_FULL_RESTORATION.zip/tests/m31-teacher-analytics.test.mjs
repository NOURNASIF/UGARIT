import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const js=fs.readFileSync(new URL('../src/js/teacher-analytics.js',import.meta.url),'utf8');
const build=fs.readFileSync(new URL('../src/build.py',import.meta.url),'utf8');
const sw=fs.readFileSync(new URL('../sw.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('M31 teacher analytics stays inside the authenticated teacher workspace',()=>{
 const gate=html.indexOf('id="teacherProtectedWorkspace"');
 const card=html.indexOf('id="teacherAnalyticsCard"');
 assert.ok(gate>=0&&card>gate);
 assert.match(html,/id="teacherAnalyticsGrade"/);
});
test('M31 analytics uses existing local attempts and aggregates grade, skill and topic data',()=>{
 assert.match(js,/localStorage\.getItem\('gq_attempts'\)/);
 assert.match(js,/a\.skills/);assert.match(js,/a\.topics/);
 assert.match(js,/teacherAnalyticsGrade/);
 assert.match(js,/أولوية دعم مقترحة/);
});
test('M31 explicitly avoids student identities and supports CSV export',()=>{
 assert.match(html,/لا تعرض أسماء الطلاب/);
 assert.match(js,/geoverse-teacher-local-analytics\.csv/);
 assert.doesNotMatch(js,/email|password|APPWRITE_API_KEY/i);
});
test('M31 build includes analytics and updates versioned shell cache',()=>{
 assert.match(build,/teacher-analytics\.js/);
 assert.equal(pkg.version,'0.1.37');
 assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});
