import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../manifest.webmanifest',import.meta.url),'utf8'));
test('M34 adds a protected content quality dashboard and completeness audit',()=>{
 assert.match(html,/id="contentQualityAudit"/);
 assert.match(app,/function buildContentQualityAudit\(\)/);
 for(const field of ['عنوان الدرس','الصف','وصف مختصر','شرح الدرس','الأهداف التعليمية','عنوان المرجع','الطبعة\/العام','الجهة الناشرة','الصفحات']) assert.ok(app.includes(field));
 assert.match(app,/function renderContentQualityAudit\(\)/);
 assert.match(app,/if\(!isPlatformContentReviewer\(\)\)/);
});
test('M34 exports an auditable CSV report without overstating verification',()=>{
 assert.match(app,/GeoVerse-content-quality-M34\.csv/);
 assert.match(app,/اكتمال الحقول لا يثبت صحة المحتوى/);
 assert.match(app,/src\.verified===true&&src\.verificationNote&&src\.pages/);
});
test('M34 increments app and service-worker versions',()=>{
 assert.equal(manifest.version,'0.1.37');
 assert.match(readFileSync(new URL('../sw.js',import.meta.url),'utf8'),/v0\.1\.37-m36/);
});
