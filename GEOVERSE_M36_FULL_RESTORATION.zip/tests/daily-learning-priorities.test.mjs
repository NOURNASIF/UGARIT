import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';

const app = readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');
const start = app.indexOf('function buildDailyLearningPriorities(');
const end = app.indexOf('\nfunction renderDailyLearningPriorities', start);
assert.ok(start >= 0 && end > start, 'pure daily priority selector is present');
const selector = vm.runInNewContext(`${app.slice(start, end)}; buildDailyLearningPriorities`);

const lessons = [
  { title: 'درس المراجعة', grades: [3] },
  { title: 'درس الضعف', grades: [3] },
  { title: 'درس جديد', grades: [3] },
  { title: 'درس صف آخر', grades: [4] },
];

test('due reviews are recommended before weak results and new lessons', () => {
  const entries = [
    { grade: 3, title: 'درس الضعف', lastQuizPercent: 35 },
    { grade: 3, title: 'درس المراجعة', lastQuizPercent: 70, nextReviewAt: '2026-11-09T12:00:00.000Z' },
  ];
  const result = selector(lessons, entries, 3, Date.parse('2026-11-10T12:00:00.000Z'), []);
  assert.deepEqual(Array.from(result, x => x.lesson.title), ['درس المراجعة', 'درس الضعف', 'درس جديد']);
  assert.deepEqual(Array.from(result, x => x.kind), ['review', 'strengthen', 'continue']);
});

test('recommendations exclude other grades, completed lessons, and missing lesson records', () => {
  const entries = [
    { grade: 4, title: 'درس صف آخر', lastQuizPercent: 10, nextReviewAt: '2026-11-01T00:00:00.000Z' },
    { grade: 3, title: 'غير موجود بالمكتبة', lastQuizPercent: 5 },
  ];
  const result = selector(lessons, entries, 3, Date.now(), ['درس المراجعة', 'درس الضعف']);
  assert.deepEqual(Array.from(result, x => x.lesson.title), ['درس جديد']);
});

test('recommendation count is capped at three and uses the available lesson list', () => {
  const moreLessons = [...lessons, { title: 'درس رابع', grades: [3] }, { title: 'درس خامس', grades: [3] }];
  const result = selector(moreLessons, [], 3, Date.now(), []);
  assert.equal(result.length, 3);
  assert.ok(result.every(x => x.kind === 'continue'));
});

test('student home contains a responsive daily priorities panel with local-data explanation', () => {
  assert.match(html, /id="dailyLearningPriorities"/);
  assert.match(app, /readLearningMemory\(\)\.entries/);
  assert.match(html, /تقدمك المحلي ومواعيد المراجعة/);
  assert.match(css, /\.daily-priority-grid/);
  assert.match(css, /@media\(max-width:520px\)\{\.daily-priority-grid/);
});
