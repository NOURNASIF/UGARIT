import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const diagnostic=fs.readFileSync(new URL('../src/js/diagnostic.js',import.meta.url),'utf8');
const app=fs.readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const sw=fs.readFileSync(new URL('../sw.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('M30 maps each diagnostic domain to an existing targeted practice skill',()=>{
 for(const code of ['maps','spatial','population','climate','economy']) assert.ok(diagnostic.includes(`code:'${code}'`));
 assert.match(diagnostic,/window\.practiceSkill\(code\)/);
 assert.match(app,/function practiceSkill\(skill\)/);
});
test('M30 provides actionable steps and reasons for every weak diagnostic domain',()=>{
 assert.equal((diagnostic.match(/steps:\[/g)||[]).length,5);
 assert.match(diagnostic,/خطتك العلاجية المقترحة/);
 assert.match(diagnostic,/سبب المراجعة|why:/);
 assert.match(diagnostic,/ابدأ تدريب هذه المهارة/);
});
test('M30 preserves M29 diagnostic records while versioning the expanded local record',()=>{
 assert.match(diagnostic,/geoverse_diagnostic_m29/);
 assert.match(diagnostic,/version:2/);
 assert.match(diagnostic,/skillCodes/);
 assert.doesNotMatch(diagnostic,/password|email|APPWRITE/i);
});
test('M30 updates the application and service-worker cache version',()=>{
 assert.equal(pkg.version,'0.1.37');
 assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});
