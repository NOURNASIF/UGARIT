import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(new URL('../'+p, import.meta.url), 'utf8');
const html = read('src/index.src.html');
const app = read('src/js/app.js');
const auth = read('modules/teacher-auth.js');
const server = read('backend/src/server.js');
const migration = read('backend/migrations/005_independent_teacher_accounts.sql');
const build = read('src/build.py');
const sw = read('sw.js');

test('M17 keeps school administration out of the student and teacher workspaces while restoring a separate school portal', () => {
  for (const token of ['view-institution','teacherOperations','teacherAcademicRecords','ugaritStudentAccount','ugaritRemoteTeacherPanel','toAttendanceGrade','toTaskForm','toPlanForm','classStudentName','classStudentCode']) assert.doesNotMatch(html, new RegExp(token));
  assert.match(html, /id="view-school"/);
  assert.match(html, /بوابة المدارس/);
  assert.match(html, /الحضور والغياب/);
  for (const token of ['ugarit_attendance_v1','ugarit_assignments_v1','ugarit_lesson_plans_v1','ugarit_academic_followups_v1','gq_exam_results_v1']) assert.doesNotMatch(app, new RegExp(token));
});

test('M16 keeps the student learning experience independent of school accounts and classes', () => {
  assert.match(html, /مكتبة الدروس/);
  assert.match(html, /مركز الاختبارات/);
  assert.match(html, /أطلس المحافظات السورية/);
  assert.match(html, /المعلم الذكي/);
  assert.doesNotMatch(auth, /\/api\/v1\/classes|assessment-attempts|school_admin|directorate_admin|refreshSession/);
});

test('M16 teacher editor is hidden by default behind a teacher-only login gate', () => {
  assert.match(html, /id="teacherAccessGate"/);
  assert.match(html, /id="teacherProtectedWorkspace" hidden/);
  assert.match(html, /id="ugaritTeacherLoginForm"/);
  assert.match(html, /id="teacherQuestionForm"/);
  const teacherView = html.slice(html.indexOf('id="view-teacher"'), html.indexOf('id="view-tutor"'));
  assert.doesNotMatch(teacherView, /teacherLearningDashboard|teacherDashMetrics|classStudentName|سجل الحضور|الغياب/);
  assert.match(html, /id="teacherLessonForm"/);
  assert.match(html, /id="examBuilderCard"/);
  assert.match(auth, /const teacherRoles = \['teacher', 'platform_admin'\]/);
  assert.match(auth, /teacherRoles\.includes\(currentUser\.role\)/);
  assert.match(auth, /لا تُستعاد جلسة المعلم تلقائياً/);
  assert.match(auth, /15 \* 60 \* 1000/);
  assert.match(app, /function teacherEditorAuthorized\(\)/);
  assert.match(app, /stopImmediatePropagation\(\)/);
  assert.match(auth, /لا يملك صلاحية دخول مساحة المعلم/);
  assert.doesNotMatch(html, /id="ugaritStudentRegisterForm"/);
});

test('M16 only platform owner can create an independent teacher account with no organization', () => {
  assert.match(html, /id="teacherAccountAdminPanel" hidden/);
  assert.match(auth, /currentUser\?\.role !== 'platform_admin'/);
  assert.match(auth, /\/api\/v1\/admin\/teacher-accounts/);
  const routeStart = server.indexOf("if(path==='/api/v1/admin/teacher-accounts'");
  const routeEnd = server.indexOf(" return send(res,404", routeStart);
  const route = server.slice(routeStart, routeEnd);
  assert.match(route, /roles\('platform_admin'\)/);
  assert.match(route, /INSERT INTO user_profiles\(id,full_name,role,status\)/);
  assert.doesNotMatch(route, /organization_id|class_id|school_id/);
  assert.match(migration, /role='teacher'/);
  assert.doesNotMatch(migration, /organization_id|class_id/);
});

test('M18 school services are isolated under their own API namespace and do not alter student/teacher login', () => {
  assert.doesNotMatch(server, /\/api\/v1\/classes|assessment-attempts|auth_refresh_sessions|auth\/refresh|auth\/register/);
  assert.match(server, /\/api\/v1\/school\/auth\/login/);
  assert.match(server, /\/api\/v1\/school\/dashboard/);
  assert.match(server, /api\/v1\/admin\/teacher-accounts/);
});

test('M18 build keeps retired school modules outside the active bundle and advances the cache key', () => {
  assert.doesNotMatch(build, /teacher-operations|admin-classroom|modules\/institution|modules\/auth/);
  assert.doesNotMatch(sw, /teacher-operations|admin-classroom|modules\/institution|modules\/auth/);
  assert.match(sw, /geoverse-shell-v0\.1\.37-m36/);
});
