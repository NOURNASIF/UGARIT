import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const manifest=JSON.parse(readFileSync(new URL('../manifest.webmanifest',import.meta.url),'utf8'));
const sw=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
test('M35 records every authorized lesson and question review transition',()=>{
 assert.match(app,/function getContentReviewAudit\(\)/);
 assert.match(app,/function recordContentReviewAudit\(kind,item,fromStatus,toStatus,note=''/);
 assert.match(app,/recordContentReviewAudit\('سؤال',item,item\.reviewStatus,status\)/);
 assert.match(app,/recordContentReviewAudit\('درس',item,item\.reviewStatus,status,note\)/);
 assert.match(app,/\['approved','needs_revision','rejected'\]/);
});
test('M35 provides a protected audit view and CSV export with local-only disclosure',()=>{
 assert.match(html,/id="contentReviewAudit"/);
 assert.match(app,/function renderContentReviewAudit\(\)/);
 assert.match(app,/GeoVerse-review-audit-M35\.csv/);
 assert.match(app,/حتى 1000 عملية/);
 assert.match(html,/لا يُعد سجلاً مركزياً أو محمياً من العبث/);
});
test('M35 increments release and service-worker cache versions',()=>{
 assert.equal(manifest.version,'0.1.37');
 assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});
