import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const app = fs.readFileSync(new URL('../src/js/app.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../src/index.src.html', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/css/styles.css', import.meta.url), 'utf8');

test('tutor exposes a grade-aware short practice entry point', () => {
  assert.match(html, /id="tutorPracticeStart"/);
  assert.match(html, /id="tutorPractice"/);
  assert.match(app, /function startTutorPractice\(\)/);
  assert.match(app, /q\.grades\.includes\(grade\)/);
});

test('practice selects only valid questions from the existing question bank', () => {
  assert.match(app, /Array\.isArray\(questionBank\)/);
  assert.match(app, /Number\.isInteger\(q\.c\)/);
  assert.match(app, /q\.c<q\.a\.length/);
});

test('practice provides answer feedback, explanations, and a final score', () => {
  assert.match(app, /function submitTutorPracticeAnswer\(choice\)/);
  assert.match(app, /q\.why/);
  assert.match(app, /انتهى التدريب/);
  assert.match(app, /تدريب جديد/);
});

test('practice controls are keyboard-operable buttons with visible correctness states', () => {
  assert.match(app, /button\.addEventListener\('click'/);
  assert.match(css, /\.tutor-practice-choice\.is-correct/);
  assert.match(css, /\.tutor-practice-choice\.is-wrong/);
});
