import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const app=fs.readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const html=fs.readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const sw=fs.readFileSync(new URL('../sw.js',import.meta.url),'utf8');
const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
test('adaptive tutor plan aggregates only valid skill results for the selected grade',()=>{
 assert.match(app,/function buildTutorAdaptivePlan\(attempts=getAttempts\(\),grade=currentGrade\)/);
 assert.match(app,/Number\(a\.grade\)===Number\(grade\)/);
 assert.match(app,/filter\(x=>x\.total>=3\)/);
 assert.match(app,/sort\(\(a,b\)=>a\.percent-b\.percent/);
});
test('adaptive tutor plan offers a direct practice action and explains local descriptive limits',()=>{
 assert.match(html,/id="tutorAdaptivePlan"/);
 assert.match(app,/تدرّب على هذه المهارة/);
 assert.match(app,/practiceSkill\(priority\.skill\)/);
 assert.match(app,/لا يصدر حكماً نهائياً على قدراتك/);
});
test('M28 increments app version and cache namespace',()=>{
 assert.equal(pkg.version,'0.1.37');
 assert.match(sw,/geoverse-shell-v0\.1\.37-m36/);
});
