import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const html=readFileSync(new URL('../src/index.src.html',import.meta.url),'utf8');
const js=readFileSync(new URL('../src/js/teacher-operations.js',import.meta.url),'utf8');
const app=readFileSync(new URL('../src/js/app.js',import.meta.url),'utf8');
const sw=readFileSync(new URL('../sw.js',import.meta.url),'utf8');
test('M15 teacher operations panel and all three workflows are present',()=>{
 for(const id of ['teacherOperations','toAttendanceGrade','toPrepareAttendance','toTaskForm','toPlanForm','toExport'])assert.match(html,new RegExp(`id="${id}"`));
 assert.match(html,/مركز العمليات التعليمية للمعلم/);
});
test('attendance workflow validates class roster limits and attendance statuses',()=>{
 assert.match(js,/names\.length>100/);assert.match(js,/present:'حاضر',absent:'غائب',late:'متأخر',excused:'غياب مبرر'/);assert.match(js,/حفظ سجل الحضور/);
});
test('assignment and lesson planning workflows enforce input limits',()=>{
 assert.match(js,/title\.length<3\|\|title\.length>120/);assert.match(js,/duration<5\|\|duration>180/);assert.match(js,/بلغت الحد المحلي للتكليفات/);
});
test('local datasets are included in backup and restore',()=>{
 for(const key of ['ugarit_attendance_v1','ugarit_assignments_v1','ugarit_lesson_plans_v1']){assert.ok(app.includes(key));}
 assert.match(app,/سجلات مركز العمليات التعليمية غير صالحة/);
});
test('CSV export and M15 cache version are configured',()=>{
 assert.match(js,/UGARIT-Teacher-Operations\.csv/);assert.match(sw,/ugarit-shell-v0\.1\.16-m15/);
});
