import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const classroom = fs.readFileSync(path.join(root, 'modules/classroom.js'), 'utf8');
const app = fs.readFileSync(path.join(root, 'src/js/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'src/index.src.html'), 'utf8');
const build = fs.readFileSync(path.join(root, 'src/build.py'), 'utf8');

test('M8 provides login, registration, session refresh and logout through the API', () => {
  for (const route of ['/api/v1/auth/login', '/api/v1/auth/register', '/api/v1/auth/refresh', '/api/v1/auth/me', '/api/v1/auth/logout']) assert.ok(classroom.includes(route));
  assert.ok(classroom.includes("credentials: 'include'"));
  assert.ok(classroom.includes('accessToken = null'));
  assert.doesNotMatch(classroom, /localStorage\.(setItem|getItem).*accessToken|localStorage\.(setItem|getItem).*password/i);
});
test('M8 loads enrolled classes and submits only the selected matching grade', () => {
  assert.ok(classroom.includes("rawRequest('/api/v1/classes')"));
  assert.ok(classroom.includes('grade_mismatch'));
  assert.ok(classroom.includes('/assessment-attempts'));
  assert.ok(classroom.includes('class_not_selected'));
});
test('M8 teacher results are rendered as text nodes from the authorized class endpoint', () => {
  assert.ok(classroom.includes('/assessment-attempts`'));
  assert.ok(classroom.includes("td.textContent = value"));
  assert.ok(classroom.includes('staffRoles'));
});
test('quiz completion keeps local saving and additionally attempts central submission', () => {
  assert.ok(app.includes('window.UgaritClassroom.submitAttempt(attempt)'));
  assert.ok(app.includes('startedAt:quizStartedAt?new Date(quizStartedAt).toISOString()'));
  assert.ok(app.includes("localStorage.setItem('gq_attempts'"));
});
test('M8 UI and build include the central classroom module without removing existing admin markers', () => {
  for (const id of ['ugaritStudentLoginForm', 'ugaritStudentRegisterForm', 'ugaritStudentClass', 'ugaritTeacherClass', 'ugaritTeacherRemoteResults']) assert.ok(html.includes(`id="${id}"`));
  assert.ok(html.includes('./modules/classroom.js'));
  assert.ok(build.includes('modules/classroom.js'));
  assert.ok(build.includes('UGARIT_ADMIN_HANDLER_READY'));
});
