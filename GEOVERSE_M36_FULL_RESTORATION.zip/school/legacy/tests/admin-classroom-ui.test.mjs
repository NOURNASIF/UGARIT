import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const moduleText = fs.readFileSync(path.join(root, 'modules/admin-classroom.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'src/index.src.html'), 'utf8');
const build = fs.readFileSync(path.join(root, 'src/build.py'), 'utf8');
const classroom = fs.readFileSync(path.join(root, 'modules/classroom.js'), 'utf8');

test('M9 management panel is present and role-gated to institution administrators', () => {
  assert.ok(html.includes('id="ugaritInstitutionAdmin"'));
  assert.ok(moduleText.includes("['school_admin', 'directorate_admin', 'platform_admin']"));
  assert.ok(moduleText.includes('panel().hidden = !visible'));
});
test('M9 UI supports creating classes, assigning teachers, and enrolling students', () => {
  for (const id of ['ugaritCreateClassForm','ugaritAdminAssignTeacher','ugaritAdminEnrollStudent','ugaritAdminRosterRows']) assert.ok(html.includes(`id="${id}"`));
  for (const route of ['/api/v1/classes','/enrollments','/api/v1/admin/users?role=teacher','/api/v1/admin/users?role=student']) assert.ok(moduleText.includes(route));
});
test('M9 user actions use server-side activation and suspension endpoints', () => {
  assert.ok(moduleText.includes("method: 'PATCH'"));
  assert.ok(moduleText.includes("updateUser(user.id, 'active')"));
  assert.ok(moduleText.includes("updateUser(user.id, 'suspended')"));
});
test('M9 uses DOM textContent for user-controlled labels and avoids injecting user HTML', () => {
  assert.ok(moduleText.includes('td.textContent = value'));
  assert.doesNotMatch(moduleText, /innerHTML\s*=/);
});
test('M9 session events and build embedding are wired', () => {
  assert.ok(classroom.includes("'ugarit:session-change'"));
  assert.ok(classroom.includes('request: rawRequest'));
  assert.ok(build.includes('modules/admin-classroom.js'));
});
test('M9 UI supports creating staff accounts and assigning unlinked student registrations to an organization', () => {
  assert.ok(html.includes('id="ugaritCreateTeacherForm"'));
  assert.ok(html.includes('id="ugaritAdminClassOrg"'));
  assert.ok(moduleText.includes("method: 'POST'"));
  assert.ok(moduleText.includes('assignUserOrganization'));
});

test('M10 provides bounded CSV preview and bulk enrollment UI', () => {
  assert.ok(html.includes('id="ugaritBulkStudentFile"'));
  assert.ok(html.includes('id="ugaritBulkImportButton"'));
  assert.ok(moduleText.includes('function parseCsvRows'));
  assert.ok(moduleText.includes('file.size>1024*1024'));
  assert.ok(moduleText.includes('valid.length>100'));
  assert.ok(moduleText.includes("JSON.stringify({emails:bulkEmails})"));
});
