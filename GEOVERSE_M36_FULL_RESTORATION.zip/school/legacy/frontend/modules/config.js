/* UGARIT v1.49 — إعدادات العميل العامة فقط. لا تضع مفاتيح أو أسراراً هنا. */
(function(g){
  const defaults={apiBaseUrl:"",apiHealthPath:"/api/v1/health",requestTimeoutMs:8000,version:"0.1.10"};
  const supplied=g.UGARIT_CONFIG||{};
  g.UGARIT_CONFIG=Object.freeze({...defaults,...supplied});
})(window);
