/* UGARIT M9 — institutional classroom administration UI. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const adminRoles = ['school_admin', 'directorate_admin', 'platform_admin'];
  let classRows = [];
  let userRows = [];
  let selectedClass = '';
  let organizations = [];
  let activeUser = null;
  let bulkEmails = [];
  const api = () => window.UgaritClassroom;
  const panel = () => $('ugaritInstitutionAdmin');
  function say(message) { const el = $('ugaritAdminClassStatus'); if (el) el.textContent = message; }
  function addOption(select, value, label) { const o = document.createElement('option'); o.value = value; o.textContent = label; select.append(o); }
  function setOptions(id, items, placeholder, labelFn) {
    const select = $(id); if (!select) return;
    select.replaceChildren(); addOption(select, '', placeholder);
    items.forEach(item => addOption(select, item.id, labelFn(item)));
  }
  function renderClasses() {
    const body = $('ugaritAdminClassRows'); if (!body) return;
    body.replaceChildren();
    classRows.forEach(item => {
      const tr = document.createElement('tr');
      [item.name, `الصف ${item.grade_level}`, item.academic_year, item.status === 'archived' ? 'مؤرشف' : 'نشط'].forEach(value => { const td = document.createElement('td'); td.textContent = value || '—'; tr.append(td); });
      tr.addEventListener('click', () => { selectedClass = item.id; const select = $('ugaritAdminClassSelect'); if (select) select.value = item.id; loadRoster(); });
      body.append(tr);
    });
    setOptions('ugaritAdminClassSelect', classRows, 'اختر صفاً', item => `${item.name} — الصف ${item.grade_level}`);
    if (selectedClass && classRows.some(c => c.id === selectedClass)) $('ugaritAdminClassSelect').value = selectedClass;
  }
  function renderUsers() {
    const body = $('ugaritAdminUserRows'); if (!body) return;
    body.replaceChildren();
    userRows.forEach(user => {
      const tr = document.createElement('tr');
      const role = ({ student: 'طالب', teacher: 'معلم', school_admin: 'مدير مدرسة', directorate_admin: 'إدارة مديرية', researcher: 'باحث' })[user.role] || user.role;
      const status = ({ pending: 'بانتظار التفعيل', active: 'نشط', suspended: 'موقوف' })[user.status] || user.status;
      [user.full_name, role, status].forEach(value => { const td = document.createElement('td'); td.textContent = value || '—'; tr.append(td); });
      const action = document.createElement('td');
      if (activeUser?.role === 'platform_admin' && user.role === 'student' && !user.organization_id) { const org = document.createElement('select'); org.className = 'field'; org.setAttribute('aria-label', 'المؤسسة'); addOption(org, '', 'اختر المؤسسة'); organizations.forEach(o => addOption(org, o.id, o.name)); const assign = document.createElement('button'); assign.type = 'button'; assign.className = 'btn small'; assign.textContent = 'ربط بالمؤسسة'; assign.addEventListener('click', () => assignUserOrganization(user.id, org.value, user.status)); action.append(org, assign); }
      if (user.status !== 'active') { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn green small'; b.textContent = 'تفعيل'; b.addEventListener('click', () => updateUser(user.id, 'active')); action.append(b); }
      if (user.status !== 'suspended') { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn ghost small'; b.textContent = 'إيقاف'; b.addEventListener('click', () => updateUser(user.id, 'suspended')); action.append(b); }
      tr.append(action); body.append(tr);
    });
  }
  async function loadClasses() {
    const data = await api().request('/api/v1/classes'); classRows = Array.isArray(data.items) ? data.items : [];
    renderClasses();
    if (activeUser?.role === 'platform_admin') {
      const orgData = await api().request('/api/v1/admin/organizations'); organizations = orgData.items || [];
      setOptions('ugaritAdminClassOrg', organizations, 'اختر المؤسسة', o => o.name);
      const orgWrap = $('ugaritAdminClassOrgWrap'); if (orgWrap) orgWrap.hidden = false;
    } else { const orgWrap = $('ugaritAdminClassOrgWrap'); if (orgWrap) orgWrap.hidden = true; }
    const roleSelect = $('ugaritNewStaffRole');
    if (roleSelect) { Array.from(roleSelect.options).forEach(option => { option.disabled = activeUser?.role === 'school_admin' && option.value !== 'teacher' || activeUser?.role === 'directorate_admin' && !['teacher','school_admin'].includes(option.value); }); roleSelect.value = 'teacher'; }
    const teachers = await api().request('/api/v1/admin/users?role=teacher&status=active');
    setOptions('ugaritAdminTeacherSelect', teachers.items || [], 'اختر معلماً نشطاً', u => u.full_name);
    const students = await api().request('/api/v1/admin/users?role=student&status=active');
    setOptions('ugaritAdminStudentSelect', students.items || [], 'اختر طالباً نشطاً', u => u.full_name);
    say(`تم تحميل ${classRows.length} صفوف وقوائم المعلمين والطلاب النشطين.`);
    if (selectedClass) await loadRoster();
  }
  async function loadUsers() {
    const status = $('ugaritAdminUserStatus')?.value || '';
    const role = $('ugaritAdminUserRole')?.value || '';
    const query = new URLSearchParams(); if (status) query.set('status', status); if (role) query.set('role', role);
    const data = await api().request('/api/v1/admin/users' + (query.size ? '?' + query.toString() : ''));
    userRows = Array.isArray(data.items) ? data.items : []; renderUsers();
    say(`تم عرض ${userRows.length} حساباً ضمن نطاق صلاحيتك.`);
  }
  async function loadRoster() {
    selectedClass = $('ugaritAdminClassSelect')?.value || selectedClass;
    const body = $('ugaritAdminRosterRows'); if (!body) return;
    if (!selectedClass) { body.replaceChildren(); return; }
    body.textContent = 'جارٍ تحميل قائمة الصف…';
    const data = await api().request(`/api/v1/classes/${encodeURIComponent(selectedClass)}/enrollments`);
    body.replaceChildren();
    (data.items || []).forEach(student => {
      const tr = document.createElement('tr');
      [student.full_name, student.status === 'active' ? 'نشط' : 'غير نشط', student.enrollment_status === 'active' ? 'مسجل' : 'منسحب'].forEach(value => { const td = document.createElement('td'); td.textContent = value || '—'; tr.append(td); });
      const td = document.createElement('td');
      if (student.enrollment_status === 'active') { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn ghost small'; b.textContent = 'إزالة من الصف'; b.addEventListener('click', async () => { try { await api().request(`/api/v1/classes/${selectedClass}/enrollments/${student.id}`, { method: 'DELETE' }); await loadRoster(); say('تم إيقاف تسجيل الطالب في الصف.'); } catch (e) { say('تعذر تحديث التسجيل: ' + e.message); } }); td.append(b); }
      tr.append(td); body.append(tr);
    });
    if (!data.items?.length) body.textContent = 'لا يوجد طلاب مسجلون في هذا الصف.';
  }
  async function assignUserOrganization(id, organizationId, status) {
    if (!organizationId) { say('اختر المؤسسة أولاً.'); return; }
    try { await api().request(`/api/v1/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify({ status, organizationId }) }); await loadUsers(); say('تم ربط حساب الطالب بالمؤسسة. بقي تفعيل الحساب وتسجيله في الصف المناسب.'); }
    catch (e) { say('تعذر ربط الحساب بالمؤسسة: ' + e.message); }
  }
  async function updateUser(id, status) {
    try { await api().request(`/api/v1/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }); await loadUsers(); say(status === 'active' ? 'تم تفعيل الحساب.' : 'تم إيقاف الحساب.'); }
    catch (e) { say('تعذر تحديث الحساب: ' + e.message); }
  }
  async function createClass(event) {
    event.preventDefault(); const form = event.currentTarget, values = new FormData(form);
    try {
      const payload = { name: values.get('name'), gradeLevel: values.get('gradeLevel'), academicYear: values.get('academicYear') }; if (activeUser?.role === 'platform_admin') payload.organizationId = $('ugaritAdminClassOrg')?.value || ''; const item = await api().request('/api/v1/classes', { method: 'POST', body: JSON.stringify(payload) });
      selectedClass = item.item.id; form.reset(); await loadClasses(); $('ugaritAdminClassSelect').value = selectedClass; say('تم إنشاء الصف بنجاح.');
    } catch (e) { say('تعذر إنشاء الصف: ' + e.message); }
  }
  async function enrollStudent() {
    const studentId = $('ugaritAdminStudentSelect')?.value; selectedClass = $('ugaritAdminClassSelect')?.value || selectedClass;
    if (!selectedClass || !studentId) { say('اختر الصف والطالب أولاً.'); return; }
    try { await api().request(`/api/v1/classes/${selectedClass}/enrollments`, { method: 'POST', body: JSON.stringify({ studentId }) }); await loadRoster(); say('تم إلحاق الطالب بالصف.'); }
    catch (e) { say('تعذر إلحاق الطالب: ' + e.message); }
  }
  async function assignTeacher() {
    selectedClass = $('ugaritAdminClassSelect')?.value || selectedClass; const teacherId = $('ugaritAdminTeacherSelect')?.value;
    if (!selectedClass || !teacherId) { say('اختر الصف والمعلم أولاً.'); return; }
    try { await api().request(`/api/v1/classes/${selectedClass}`, { method: 'PATCH', body: JSON.stringify({ teacherId }) }); await loadClasses(); say('تم إسناد المعلم إلى الصف.'); }
    catch (e) { say('تعذر إسناد المعلم: ' + e.message); }
  }
  async function createStaff(event) {
    event.preventDefault(); const form = event.currentTarget, values = new FormData(form);
    const payload = { fullName: values.get('fullName'), email: values.get('email'), role: values.get('role'), password: values.get('password') };
    if (activeUser?.role === 'platform_admin') payload.organizationId = $('ugaritAdminClassOrg')?.value || '';
    try { await api().request('/api/v1/admin/users', { method: 'POST', body: JSON.stringify(payload) }); form.reset(); if ($('ugaritNewStaffRole')) $('ugaritNewStaffRole').value = 'teacher'; await loadClasses(); await loadUsers(); say('تم إنشاء الحساب وتفعيله. سلّم كلمة المرور المؤقتة لصاحب الحساب عبر قناة آمنة.'); }
    catch (e) { say('تعذر إنشاء الحساب: ' + e.message); }
  }

  function parseCsvRows(text) {
    const rows=[]; let row=[], cell='', quoted=false;
    for(let i=0;i<text.length;i++) { const ch=text[i];
      if(ch==='"' && quoted && text[i+1]==='"'){cell+='"';i++;}
      else if(ch==='"') quoted=!quoted;
      else if(ch===',' && !quoted){row.push(cell.trim());cell='';}
      else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cell.trim());if(row.some(Boolean))rows.push(row);row=[];cell='';}
      else cell+=ch;
    }
    row.push(cell.trim());if(row.some(Boolean))rows.push(row);return rows;
  }
  async function previewBulkFile(file) {
    const preview=$('ugaritBulkPreview'),button=$('ugaritBulkImportButton'),result=$('ugaritBulkResult');
    bulkEmails=[];button.disabled=true;result.textContent='';
    if(!file){preview.textContent='لم يتم اختيار ملف.';return;}
    if(file.size>1024*1024){preview.textContent='حجم الملف يتجاوز 1 ميغابايت.';return;}
    try {
      const rows=parseCsvRows((await file.text()).replace(/^\uFEFF/,''));
      if(!rows.length)throw new Error('الملف فارغ.');
      const header=rows[0].map(x=>x.toLowerCase());
      const emailIndex=header.findIndex(x=>['email','البريد الإلكتروني','البريد الالكتروني','البريد'].includes(x));
      const index=emailIndex>=0?emailIndex:0; const values=rows.slice(emailIndex>=0?1:0).map(r=>(r[index]||'').trim().toLowerCase()).filter(Boolean);
      const unique=[...new Set(values)];
      const valid=unique.filter(x=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x));
      const invalid=unique.length-valid.length;
      if(!valid.length)throw new Error('لم نعثر على عناوين بريد إلكتروني صالحة.');
      if(valid.length>100)throw new Error(`الملف يحتوي ${valid.length} بريداً صالحاً؛ الحد الأقصى 100. قسّم الملف إلى دفعات.`);
      bulkEmails=valid;button.disabled=false;
      preview.textContent=`تم العثور على ${valid.length} بريداً صالحاً، ${invalid} غير صالح، و${values.length-unique.length} مكرراً. ستتم مطابقة الحسابات النشطة في المؤسسة والصف المحددين.`;
    } catch(e){preview.textContent=e.message;}
  }
  async function submitBulkImport(){
    const button=$('ugaritBulkImportButton'),result=$('ugaritBulkResult');
    selectedClass=$('ugaritAdminClassSelect')?.value||selectedClass;
    if(!selectedClass){result.textContent='اختر الصف أولاً.';return;}
    if(!bulkEmails.length){result.textContent='اختر ملفاً صالحاً أولاً.';return;}
    button.disabled=true;result.textContent='جارٍ التحقق من الحسابات وتسجيل الطلاب…';
    try{
      const data=await api().request(`/api/v1/classes/${encodeURIComponent(selectedClass)}/enrollments`,{method:'POST',body:JSON.stringify({emails:bulkEmails})});
      const item=data.item||{};result.textContent=`اكتمل الاستيراد: ${item.added?.length||0} ناجح، ${item.rejected?.length||0} مرفوض. الحسابات غير الموجودة أو غير النشطة أو التابعة لمؤسسة أخرى لم تُسجّل.`;
      await loadRoster();
    }catch(e){result.textContent='تعذر الاستيراد: '+e.message;}
    finally{button.disabled=!bulkEmails.length;}
  }

  function sessionChanged() {
    const user = api()?.getUser(); activeUser = user || null; const visible = !!user && adminRoles.includes(user.role);
    if (panel()) panel().hidden = !visible;
    if (visible) { loadClasses().then(loadUsers).catch(e => say('تعذر تحميل بيانات الإدارة: ' + e.message)); }
    else { classRows = []; userRows = []; selectedClass = ''; }
  }
  document.addEventListener('DOMContentLoaded', () => {
    document.addEventListener('ugarit:session-change', sessionChanged);
    $('ugaritCreateClassForm')?.addEventListener('submit', createClass);
    $('ugaritCreateTeacherForm')?.addEventListener('submit', createStaff);
    $('ugaritAdminRefreshClasses')?.addEventListener('click', () => loadClasses().catch(e => say(e.message)));
    $('ugaritAdminLoadUsers')?.addEventListener('click', () => loadUsers().catch(e => say(e.message)));
    $('ugaritAdminClassSelect')?.addEventListener('change', () => { selectedClass = $('ugaritAdminClassSelect').value; loadRoster().catch(e => say(e.message)); });
    $('ugaritAdminEnrollStudent')?.addEventListener('click', enrollStudent);
    $('ugaritAdminAssignTeacher')?.addEventListener('click', assignTeacher);
    $('ugaritBulkStudentFile')?.addEventListener('change', e => previewBulkFile(e.target.files?.[0]));
    $('ugaritBulkImportButton')?.addEventListener('click', submitBulkImport);
    if (api()?.getUser()) sessionChanged();
  });
})();
