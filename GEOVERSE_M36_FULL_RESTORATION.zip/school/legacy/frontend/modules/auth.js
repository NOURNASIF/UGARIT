/* UGARIT v1.49 — واجهة مصادقة خادمية؛ لا تخزن كلمات المرور أو الرموز في localStorage. */
(function(){
 'use strict';
 let accessToken=null,user=null;
 const $=id=>document.getElementById(id);
 const cfg=()=>window.UGARIT_CONFIG||{};
 const api=()=>String(cfg().apiBaseUrl||'').replace(/\/$/,'');
 function status(message){const el=$('ugaritAuthStatus');if(el)el.textContent=message;}
 async function request(path,options={}){
  if(!api())throw new Error('لم يُضبط عنوان API. الخادم المركزي غير متاح حالياً.');
  const headers={'Accept':'application/json',...(options.body?{'Content-Type':'application/json'}:{}),...(accessToken?{Authorization:'Bearer '+accessToken}:{}),...(options.headers||{})};
  const res=await fetch(api()+path,{...options,headers,credentials:'include',cache:'no-store'});
  const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.message||data.error||('HTTP '+res.status));return data;
 }
 function render(){const logout=$('ugaritLogoutBtn');if(logout)logout.hidden=!user;if(user)status(`تم التحقق من الهوية: ${user.fullName||user.full_name} — الدور: ${user.role}`);}
 async function login(e){e.preventDefault();const f=e.currentTarget,b=new FormData(f);try{status('جارٍ التحقق من بيانات الدخول…');const data=await request('/api/v1/auth/login',{method:'POST',body:JSON.stringify({email:b.get('email'),password:b.get('password')})});accessToken=data.accessToken;user=data.user;f.reset();render();}catch(err){status('تعذر تسجيل الدخول: '+err.message);}}
 async function register(e){e.preventDefault();const f=e.currentTarget,b=new FormData(f);try{status('جارٍ إرسال طلب إنشاء الحساب…');const data=await request('/api/v1/auth/register',{method:'POST',body:JSON.stringify({fullName:b.get('fullName'),email:b.get('email'),password:b.get('password')})});f.reset();status(data.message||'تم إرسال الطلب.');}catch(err){status('تعذر إنشاء الحساب: '+err.message);}}
 async function logout(){try{await request('/api/v1/auth/logout',{method:'POST'});}catch(_){}accessToken=null;user=null;status('تم تسجيل الخروج من هذه الجلسة.');render();}
 document.addEventListener('DOMContentLoaded',()=>{
  $('ugaritLoginForm')?.addEventListener('submit',login);$('ugaritRegisterForm')?.addEventListener('submit',register);$('ugaritLogoutBtn')?.addEventListener('click',logout);
  if(api())request('/api/v1/auth/refresh',{method:'POST'}).then(d=>{accessToken=d.accessToken;return request('/api/v1/auth/me');}).then(d=>{user=d.user;render();}).catch(()=>{});
 });
 window.UgaritAuth={getUser:()=>user,logout};
})();
