/* UGARIT M8 — ربط المصادقة والاختبارات وتقارير الصف بالـ API المركزي.
   لا تُخزّن كلمات المرور أو رموز الوصول في localStorage/sessionStorage. */
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  let accessToken = null;
  let currentUser = null;
  let classes = [];
  let selectedClassId = '';
  const cfg = () => window.UGARIT_CONFIG || {};
  const apiBase = () => String(cfg().apiBaseUrl || '').replace(/\/$/, '');
  const studentRoles = ['student'];
  const staffRoles = ['teacher', 'school_admin', 'directorate_admin'];

  function status(message) {
    const el = $('ugaritStudentAuthStatus');
    if (el) el.textContent = message;
  }
  function remoteStatus(message) {
    const el = $('ugaritTeacherRemoteStatus');
    if (el) el.textContent = message;
  }
  async function rawRequest(path, options = {}, retry = true) {
    if (!apiBase()) throw new Error('عنوان الخادم المركزي غير مضبوط. يلزم نشر API وضبط apiBaseUrl أولاً.');
    const headers = { Accept: 'application/json', ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}), ...(options.headers || {}) };
    const response = await fetch(apiBase() + path, { ...options, headers, credentials: 'include', cache: 'no-store' });
    const data = await response.json().catch(() => ({}));
    if (response.status === 401 && retry && !path.includes('/auth/login') && !path.includes('/auth/register') && !path.includes('/auth/refresh')) {
      await refreshSession();
      return rawRequest(path, options, false);
    }
    if (!response.ok) {
      const error = new Error(data.message || data.error || `HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return data;
  }
  async function refreshSession() {
    const data = await rawRequest('/api/v1/auth/refresh', { method: 'POST' }, false);
    accessToken = data.accessToken;
    if (!accessToken) throw new Error('تعذر تجديد جلسة الدخول.');
    return accessToken;
  }
  function fillClassSelect(select, list, placeholder) {
    if (!select) return;
    select.replaceChildren();
    const first = document.createElement('option');
    first.value = '';
    first.textContent = placeholder;
    select.append(first);
    list.forEach(item => {
      const option = document.createElement('option');
      option.value = item.id;
      option.textContent = `${item.name} — الصف ${item.grade_level}`;
      select.append(option);
    });
  }
  function renderSession() {
    document.dispatchEvent(new CustomEvent('ugarit:session-change', { detail: { user: currentUser } }));
    const forms = $('ugaritStudentAuthForms');
    const session = $('ugaritStudentSession');
    const identity = $('ugaritStudentIdentity');
    const studentPanel = $('ugaritStudentAccount');
    const teacherPanel = $('ugaritRemoteTeacherPanel');
    if (forms) forms.hidden = !!currentUser;
    if (session) session.hidden = !currentUser;
    if (identity && currentUser) identity.textContent = `${currentUser.fullName || currentUser.full_name} — ${currentUser.role}`;
    if (studentPanel) studentPanel.hidden = !!currentUser && !studentRoles.includes(currentUser.role);
    if (teacherPanel) teacherPanel.hidden = !currentUser || !staffRoles.includes(currentUser.role);
    if (!currentUser) {
      classes = [];
      selectedClassId = '';
      fillClassSelect($('ugaritStudentClass'), [], 'سجّل الدخول أولاً');
      fillClassSelect($('ugaritTeacherClass'), [], 'سجّل الدخول أولاً');
      return;
    }
    if (studentRoles.includes(currentUser.role)) {
      fillClassSelect($('ugaritStudentClass'), classes, 'اختر صفاً مسجلاً');
      const selector = $('ugaritStudentClass');
      if (selector && selectedClassId) selector.value = selectedClassId;
    }
    if (staffRoles.includes(currentUser.role)) fillClassSelect($('ugaritTeacherClass'), classes, 'اختر صفاً');
  }
  async function loadClasses() {
    const data = await rawRequest('/api/v1/classes');
    classes = Array.isArray(data.items) ? data.items : [];
    renderSession();
    if (currentUser?.role === 'student') {
      if (!classes.length) status('تم تسجيل الدخول، لكن لا يوجد صف نشط مسجل لحسابك بعد. اطلب من مسؤول المؤسسة إكمال تسجيلك.');
      else status('تم تسجيل الدخول وتحميل صفوفك المسجلة. اختر الصف المطابق قبل بدء الاختبار.');
    } else if (staffRoles.includes(currentUser?.role)) {
      remoteStatus('تم تسجيل الدخول. اختر أحد الصفوف المصرح بها لتحميل النتائج.');
    }
  }
  async function login(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    try {
      status('جارٍ التحقق من بيانات الحساب…');
      const data = await rawRequest('/api/v1/auth/login', { method: 'POST', body: JSON.stringify({ email: values.get('email'), password: values.get('password') }) }, false);
      accessToken = data.accessToken;
      currentUser = data.user;
      form.reset();
      renderSession();
      await loadClasses();
    } catch (error) {
      accessToken = null; currentUser = null; renderSession();
      status('تعذر تسجيل الدخول: ' + error.message);
    }
  }
  async function register(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    try {
      status('جارٍ إرسال طلب إنشاء الحساب…');
      const data = await rawRequest('/api/v1/auth/register', { method: 'POST', body: JSON.stringify({ fullName: values.get('fullName'), email: values.get('email'), password: values.get('password') }) }, false);
      form.reset();
      status(data.message || 'تم إرسال طلب الحساب. يجب تفعيله من مسؤول المؤسسة قبل الدخول.');
    } catch (error) { status('تعذر إرسال الطلب: ' + error.message); }
  }
  async function logout() {
    try { if (apiBase()) await rawRequest('/api/v1/auth/logout', { method: 'POST' }, false); } catch (_) { /* local session is still cleared */ }
    accessToken = null; currentUser = null; classes = []; selectedClassId = '';
    const results = $('ugaritTeacherRemoteResults'); if (results) results.replaceChildren();
    renderSession();
    status('تم تسجيل الخروج من هذه الجلسة.');
    remoteStatus('سجّل الدخول بحساب مخوّل لعرض النتائج.');
  }
  function normalizeSummary(items, key) {
    return (Array.isArray(items) ? items : []).map(item => ({ [key]: String(item[key] || '').slice(0, 80), correct: Number(item.correct) || 0, total: Number(item.total) || 0 }));
  }
  async function submitAttempt(attempt) {
    if (!currentUser || !studentRoles.includes(currentUser.role)) return { skipped: true, reason: 'no_student_session' };
    const classId = selectedClassId || $('ugaritStudentClass')?.value || '';
    if (!classId) { status('لم تُرسل النتيجة مركزياً: اختر صفاً مسجلاً في حسابك أولاً. حُفظت النتيجة محلياً على هذا الجهاز.'); return { skipped: true, reason: 'class_not_selected' }; }
    const enrolledClass = classes.find(item => item.id === classId);
    const classGrade = Number(enrolledClass?.grade_level);
    if (!Number.isInteger(classGrade) || classGrade !== Number(attempt.grade)) {
      status('لم تُرسل النتيجة مركزياً: الصف المحدد في الحساب لا يطابق صف الاختبار الحالي. غيّر الصف من قائمة المنصة أو اختر الصف المسجل الصحيح.');
      return { skipped: true, reason: 'grade_mismatch' };
    }
    const selectedTopic = $('quizTopic');
    const topic = selectedTopic?.value === 'all' ? 'اختبار متنوع' : (selectedTopic?.selectedOptions?.[0]?.textContent || attempt.topic || 'جغرافيا');
    const payload = {
      topic: String(topic).slice(0, 100), score: Number(attempt.score), maxScore: Number(attempt.total),
      durationSeconds: Math.min(14400, Math.max(0, Number(attempt.elapsedSeconds) || 0)),
      startedAt: attempt.startedAt || new Date().toISOString(),
      skills: normalizeSummary(attempt.skills, 'skill'),
      topics: normalizeSummary(attempt.topics, 'topic')
    };
    try {
      await rawRequest(`/api/v1/classes/${encodeURIComponent(classId)}/assessment-attempts`, { method: 'POST', body: JSON.stringify(payload) });
      status('تم حفظ نتيجة الاختبار محلياً ومركزياً في سجل صفك.');
      return { saved: true };
    } catch (error) {
      status('حُفظت النتيجة محلياً، لكن تعذر إرسالها مركزياً: ' + error.message);
      return { saved: false, error: error.message };
    }
  }
  async function loadTeacherResults() {
    const classId = $('ugaritTeacherClass')?.value || '';
    const host = $('ugaritTeacherRemoteResults');
    if (!classId) { remoteStatus('اختر صفاً أولاً.'); return; }
    if (host) host.textContent = 'جارٍ تحميل النتائج…';
    try {
      const data = await rawRequest(`/api/v1/classes/${encodeURIComponent(classId)}/assessment-attempts`);
      const rows = Array.isArray(data.items) ? data.items : [];
      if (!host) return;
      if (!rows.length) { host.textContent = 'لا توجد نتائج مركزية مسجلة لهذا الصف حتى الآن.'; remoteStatus('اكتمل التحميل — لا توجد محاولات بعد.'); return; }
      const table = document.createElement('table'); table.className = 'skill-table';
      const thead = document.createElement('thead');
      const head = document.createElement('tr');
      ['الطالب', 'الموضوع', 'النتيجة', 'النسبة', 'المدة', 'التاريخ'].forEach(label => { const th = document.createElement('th'); th.textContent = label; head.append(th); });
      thead.append(head); table.append(thead);
      const tbody = document.createElement('tbody');
      rows.forEach(row => {
        const tr = document.createElement('tr');
        const values = [row.student_name || 'طالب', row.topic || '—', `${row.score}/${row.max_score}`, `${Number(row.percent).toFixed(1)}٪`, `${Math.round(Number(row.duration_seconds || 0) / 60)} د`, row.submitted_at ? new Date(row.submitted_at).toLocaleDateString('ar-QA') : '—'];
        values.forEach(value => { const td = document.createElement('td'); td.textContent = value; tr.append(td); });
        tbody.append(tr);
      });
      table.append(tbody); host.replaceChildren(table);
      remoteStatus(`تم تحميل ${rows.length} محاولة من الصف المصرح به.`);
    } catch (error) {
      if (host) host.textContent = 'تعذر تحميل النتائج. تحقق من صلاحية الحساب وإعداد الخادم.';
      remoteStatus('فشل التحميل: ' + error.message);
    }
  }
  async function restoreSession() {
    if (!apiBase()) { status('الاتصال المركزي غير مهيأ بعد؛ تبقى الاختبارات المحلية متاحة دون تغيير.'); return; }
    try {
      await refreshSession();
      const data = await rawRequest('/api/v1/auth/me');
      currentUser = data.user;
      renderSession();
      await loadClasses();
    } catch (_) { accessToken = null; currentUser = null; renderSession(); }
  }
  document.addEventListener('DOMContentLoaded', () => {
    $('ugaritStudentLoginForm')?.addEventListener('submit', login);
    $('ugaritStudentRegisterForm')?.addEventListener('submit', register);
    $('ugaritStudentLogout')?.addEventListener('click', logout);
    $('ugaritTeacherLogout')?.addEventListener('click', logout);
    $('ugaritStudentClass')?.addEventListener('change', event => { selectedClassId = event.target.value; });
    $('ugaritTeacherLoad')?.addEventListener('click', loadTeacherResults);
    restoreSession();
  });
  window.UgaritClassroom = Object.freeze({ getUser: () => currentUser, getClasses: () => classes.slice(), request: rawRequest, refreshClasses: loadClasses, submitAttempt, loadTeacherResults, logout });
})();
