/* UGARIT v1.49 — لوحة الجاهزية المؤسسية ومؤشرات تكامل الخادم. */
(function(){
 'use strict';
 const $=id=>document.getElementById(id);
 const checks=[
  ['الواجهة التعليمية الحالية','موجودة — تم الحفاظ على وحدات 1.37','done'],
  ['هيكل إعدادات API','أُضيف — يحتاج عنوان خادم منشور','done'],
  ['خادم API أولي','نقاط الصحة والهوية والموارد والصفوف موجودة في الحزمة','done'],
  ['مخطط PostgreSQL','أضيفت جداول الهوية والجلسات وسياسات RLS التأسيسية — غير منشور','done'],
  ['مصادقة وإدارة جلسات','رموز قصيرة العمر وتجديد Cookie خادمي — تحتاج مراجعة ونشر','pending'],
  ['صلاحيات متعددة المؤسسات','فحص أدوار وسياسات RLS أولية — تحتاج اختباراً أمنياً','pending'],
  ['نسخ احتياطي ومراقبة تشغيل','تحتاج إعداداً على بيئة الاستضافة','pending'],
  ['مزامنة التقدم والاختبارات','تحتاج استكمال نقاط API واختبارات التكامل','pending']
 ];
 function render(){
  const list=$('instReadinessList'); if(list) list.innerHTML=checks.map(([name,detail,state])=>`<div style="display:flex;gap:12px;align-items:flex-start;justify-content:space-between;border-bottom:1px solid var(--line);padding:9px 0"><div><strong>${escapeHtml(name)}</strong><div class="muted" style="font-size:12px">${escapeHtml(detail)}</div></div><span class="tag">${state==='done'?'منجز في الحزمة':'يتطلب الخادم'}</span></div>`).join('');
  const count=Object.keys(localStorage).filter(k=>k.toLowerCase().includes('ugarit')).length;
  if($('instLocalCount')) $('instLocalCount').textContent=String(count);
  if($('instApiStatus')) $('instApiStatus').textContent=window.UGARIT_CONFIG.apiBaseUrl?'جاهز للفحص':'غير مهيأ';
  if($('instApiDetail')) $('instApiDetail').textContent=window.UGARIT_CONFIG.apiBaseUrl||'اضبط apiBaseUrl بعد نشر الخادم';
 }
 function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
 async function checkApi(){
  const status=$('instActionStatus'),btn=$('instCheckApi'); if(!status)return;
  const cfg=window.UGARIT_CONFIG||{};
  if(!cfg.apiBaseUrl){status.textContent='لم يُضبط عنوان الخادم. لا يوجد اتصال إنتاجي حالياً.';return;}
  btn.disabled=true; status.textContent='جارٍ فحص نقطة الصحة…';
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),cfg.requestTimeoutMs||8000);
  try{
   const url=new URL(cfg.apiHealthPath||'/api/v1/health',cfg.apiBaseUrl);
   const res=await fetch(url,{method:'GET',headers:{'Accept':'application/json'},credentials:'omit',signal:controller.signal,cache:'no-store'});
   if(!res.ok)throw new Error('HTTP '+res.status);
   const data=await res.json();
   status.textContent=data.status==='ok'?'الخادم متاح — '+(data.service||'UGARIT API'):'استجابة وصلت، لكن حالة الخدمة غير مؤكدة.';
  }catch(e){status.textContent=e.name==='AbortError'?'انتهت مهلة الاتصال.':'تعذر الاتصال: '+e.message;}
  finally{clearTimeout(timer);btn.disabled=false;}
 }
 function exportInventory(){
  const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.toLowerCase().includes('ugarit'))keys.push({key:k,characters:(localStorage.getItem(k)||'').length});}
  const payload={product:'UGARIT',version:'0.1.10',generatedAt:new Date().toISOString(),note:'جرد أسماء مفاتيح التخزين وأحجامها فقط؛ لا يتضمن محتويات أو بيانات شخصية.',localStorageKeys:keys};
  const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ugarit-local-inventory-v0.1.json';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  if($('instActionStatus'))$('instActionStatus').textContent='تم إنشاء ملف الجرد دون تصدير محتويات المستخدمين.';
 }
 document.addEventListener('DOMContentLoaded',()=>{
  render(); const c=$('instCheckApi'),e=$('instExportInventory');if(c)c.addEventListener('click',checkApi);if(e)e.addEventListener('click',exportInventory);
 });
 window.UgaritInstitution={refresh:render,checkApi};
})();
