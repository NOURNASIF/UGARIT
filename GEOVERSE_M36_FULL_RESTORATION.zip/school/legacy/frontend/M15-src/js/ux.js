/* UGARIT v1.40 — تحسينات الجوال وإمكانية الوصول (تعمل فوق navigate في app.js دون تغيير منطقه) */
(function(){
 'use strict';
 const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
 const MAP_IDS=["challengeMap", "map", "themeMap", "atlasMap"],QUICK={home:'الرئيسية',lessons:'الدروس',map:'الخريطة',quiz:'الاختبارات'};
 const mk=(t,c,html)=>{const e=document.createElement(t);if(c)e.className=c;if(html!=null)e.innerHTML=html;return e;};
 const items=()=>$$('.nav > button[data-view], .nav > .nav-group > .nav-parent, .nav > button:not(.nav-parent)[data-view]').map(b=>({v:b.dataset.view,ico:(b.querySelector('.ico')||{}).textContent||'',label:b.textContent.replace((b.querySelector('.ico')||{}).textContent||'','').trim()}));
 let bar,sheet,back,moreBtn,lastFocus;
 function sync(v){
  if(!bar)return;
  bar.querySelectorAll('button[data-view]').forEach(b=>{const on=b.dataset.view===v;b.classList.toggle('active',on);on?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current');});
  moreBtn.classList.toggle('active',!(v in QUICK));
  sheet.querySelectorAll('button[data-view]').forEach(b=>{b.dataset.view===v?b.setAttribute('aria-current','page'):b.removeAttribute('aria-current');});
 }
 function setSheet(open){
  sheet.classList.toggle('is-open',open);sheet.setAttribute('aria-hidden',String(!open));back.classList.toggle('is-open',open);moreBtn.setAttribute('aria-expanded',String(open));document.body.classList.toggle('menu-open',open);
  if(open){lastFocus=document.activeElement;(sheet.querySelector('button[aria-current]')||sheet.querySelector('button')).focus();}
  else if(lastFocus&&lastFocus.focus){lastFocus.focus();}
 }
 function go(v){navigate(v);const m=$('#mainContent');if(m)m.focus({preventScroll:true});}
 function mapFallback(){
  const noLib=typeof L==='undefined';
  MAP_IDS.forEach(id=>{const el=document.getElementById(id);if(!el)return;
   const stale=el.querySelector('.map-fallback');
   if(!noLib&&stale)stale.remove();
   if(noLib&&!el.querySelector('.map-fallback'))el.innerHTML='<div class="map-fallback" role="alert"><strong>تعذّر تحميل الخريطة</strong><p>تحتاج الخرائط إلى اتصال بالإنترنت. تحقق من الاتصال ثم أعد المحاولة.</p><button class="btn small" type="button" data-reload>إعادة المحاولة</button></div>';});
 }
 function build(){
  const all=items(),by=Object.fromEntries(all.map(i=>[i.v,i]));
  bar=mk('nav','bottom-nav');bar.setAttribute('aria-label','التنقل السريع');
  Object.keys(QUICK).forEach(v=>{if(by[v])bar.appendChild(mk('button',null,'<span class="ico" aria-hidden="true">'+by[v].ico+'</span>'+QUICK[v])).dataset.view=v;});
  moreBtn=bar.appendChild(mk('button',null,'<span class="ico" aria-hidden="true">☰</span>المزيد'));moreBtn.type='button';
  moreBtn.setAttribute('aria-haspopup','dialog');moreBtn.setAttribute('aria-expanded','false');
  back=mk('div','more-backdrop');sheet=mk('div','more-sheet','<h2>كل الأقسام</h2>');
  sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');sheet.setAttribute('aria-label','كل الأقسام');sheet.setAttribute('aria-hidden','true');
  const grid=sheet.appendChild(mk('div','more-grid'));
  all.forEach(i=>{const b=grid.appendChild(mk('button',null,'<span class="ico" aria-hidden="true">'+i.ico+'</span>'+i.label));b.type='button';b.dataset.view=i.v;});
  document.body.append(bar,back,sheet);
  bar.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b===moreBtn)return setSheet(!sheet.classList.contains('is-open'));if(b.dataset.view)go(b.dataset.view);});
  sheet.addEventListener('click',e=>{const b=e.target.closest('button[data-view]');if(b){setSheet(false);go(b.dataset.view);}});
  back.addEventListener('click',()=>setSheet(false));
  document.addEventListener('keydown',e=>{
   if(!sheet.classList.contains('is-open'))return;
   if(e.key==='Escape')return setSheet(false);
   if(e.key==='Tab'){const f=[...sheet.querySelectorAll('button')],a=f[0],z=f[f.length-1];
    if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus();}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus();}}
  });
  const base=window.navigate;
  if(typeof base==='function')window.navigate=function(v){mapFallback();const r=base.apply(this,[v].concat([].slice.call(arguments,1)));sync(v);route(v);setTimeout(mapFallback,300);return r;};
  const cur=$('.view.active');sync(cur?cur.id.replace('view-',''):'home');
 }
 document.addEventListener('click',e=>{
  const parent=e.target.closest('.nav-parent');if(parent){const group=parent.closest('.nav-group'),sub=group&&group.querySelector('.nav-submenu'),active=$('.view.active'),onMapHome=!!active&&active.id==='view-map';if(sub&&onMapHome&&!sub.hidden){sub.hidden=true;parent.setAttribute('aria-expanded','false');return;}if(sub){sub.hidden=false;parent.setAttribute('aria-expanded','true');}if(typeof navigate==='function'&&!onMapHome)navigate('map');return;}
  const g=e.target.closest('[data-goto]');if(g){e.preventDefault();go(g.dataset.goto);}
  if(e.target.closest('[data-reload]'))location.reload();
 });

 const BASE_TITLE='أوغاريت | منصة الجغرافيا السورية الذكية';let fromHash=false;
 const validView=v=>!!v&&!!document.getElementById('view-'+v);
 function route(v){
  const lab=(typeof labels!=='undefined'&&labels[v])||v;
  document.title=v==='home'?BASE_TITLE:lab+' — أوغاريت';
  if(fromHash)return;
  try{if(location.hash!=='#'+v)history.pushState({v:v},'','#'+v);}catch(_){}
 }
 function share(btn){
  const url=location.href,title=document.title;
  if(navigator.share)return navigator.share({title:title,url:url}).catch(()=>{});
  if(navigator.clipboard)return navigator.clipboard.writeText(url).then(()=>{const t=btn.textContent;btn.textContent='تم نسخ الرابط ✓';setTimeout(()=>{btn.textContent=t;},1600);}).catch(()=>{});
 }
 function initRouting(){
  if(/^https?:$/.test(location.protocol)){
   const tr=$('.top-right');
   if(tr){const b=mk('button','btn ghost small share-top','مشاركة');b.type='button';b.dataset.share='1';b.setAttribute('aria-label','مشاركة رابط هذا القسم');tr.insertBefore(b,tr.firstChild);}
   if(sheet){const s=mk('button','btn ghost share-sheet','مشاركة رابط هذا القسم');s.type='button';s.dataset.share='1';sheet.appendChild(s);}
  }
  const h=location.hash.slice(1);
  if(validView(h)){fromHash=true;navigate(h);fromHash=false;}
 }
 window.addEventListener('hashchange',()=>{
  const v=location.hash.slice(1),cur=$('.view.active');
  if(validView(v)&&(!cur||cur.id!=='view-'+v)){fromHash=true;navigate(v);fromHash=false;}
 });
 document.addEventListener('click',e=>{const s=e.target.closest('[data-share]');if(s)share(s);});
 document.addEventListener('DOMContentLoaded',build);
 document.addEventListener('DOMContentLoaded',initRouting);
 window.addEventListener('load',()=>setTimeout(mapFallback,1200));
})();
