/* UGARIT v1.45 — أطلس المحافظات السورية */
(function(){
'use strict';
const $=s=>document.querySelector(s);
if(typeof labels!=='undefined')labels.atlas='أطلس المحافظات';
const GOV=[["دمشق", "دمشق وريفها", 33.5138, 36.2765, "العاصمة، تقع في الجنوب الغربي عند سفح سلسلة جبال لبنان الشرقية على نهر بردى، وتحيط بها الغوطة الزراعية.", "مركز إداري وتجاري وخدمي ونقطة التقاء طرق رئيسية.", "كيف أثّر نهر بردى في نشأة المدينة ونموها؟"], ["ريف دمشق", "دمشق وريفها", 33.57, 36.4, "تحيط بالعاصمة من معظم الجهات، وتضم الغوطة والقلمون وأجزاء من جبل الشيخ.", "زراعة وصناعات متنوعة وتجمعات سكنية متصلة بالعاصمة.", "ما أثر القرب من العاصمة في استعمالات الأرض هنا؟"], ["حلب", "الشمال", 36.2021, 37.1343, "في الشمال قرب الحدود التركية، تقع على طرق التجارة التاريخية بين المتوسط والداخل والعراق.", "مركز تجاري وصناعي تاريخي، وزراعة الحبوب والزيتون في الريف.", "لماذا ازدهرت التجارة في مدينة تقع عند ملتقى الطرق؟"], ["حمص", "الوسط", 34.7324, 36.7137, "في وسط البلاد، من أكبر المحافظات مساحة، تمتد من وادي العاصي حتى أطراف البادية وفيها تدمر.", "عقدة نقل بين الساحل والداخل، وزراعة في السهول، ورعي في البادية.", "كيف يتغير نمط الحياة بين وادي العاصي والبادية في المحافظة نفسها؟"], ["حماة", "الوسط", 35.1318, 36.751, "في وسط البلاد، يجري فيها نهر العاصي وتشتهر بالنواعير، وتضم جزءاً من سهل الغاب.", "زراعة الحبوب والخضار والفاكهة اعتماداً على مياه العاصي والأمطار.", "ما أهمية النواعير في رفع مياه النهر قديماً؟"], ["اللاذقية", "الساحل", 35.5317, 35.7901, "على البحر المتوسط غرباً، تتجاور فيها الجبال الساحلية والسهل الضيق، وفيها مرفأ رئيسي.", "زراعة الحمضيات والزيتون والتبغ، وأنشطة المرفأ والسياحة.", "كيف يؤثر قرب الجبال من البحر في كمية الأمطار؟"], ["طرطوس", "الساحل", 34.889, 35.8866, "على الساحل جنوب اللاذقية، سهل ساحلي مطل على المتوسط وخلفه مرتفعات.", "زراعة الخضار والحمضيات والزيتون، ومرفأ، وسياحة ساحلية.", "لماذا تُزرع الخضار والحمضيات بكثرة على الشريط الساحلي؟"], ["إدلب", "الشمال", 35.9306, 36.6339, "في الشمال الغربي قرب الحدود التركية، فيها مرتفعات مثل جبل الزاوية وسهول واسعة.", "تشتهر بزراعة الزيتون والحبوب.", "ما علاقة المناخ المتوسطي بانتشار أشجار الزيتون؟"], ["الحسكة", "الشرق", 36.5024, 40.7477, "في أقصى الشمال الشرقي ضمن الجزيرة السورية، سهول واسعة وأنهار مثل الخابور وحدود مع تركيا والعراق.", "زراعة القمح والقطن والشعير وتربية المواشي.", "كيف تؤثر قلة الأمطار نسبياً في اختيار المحاصيل؟"], ["دير الزور", "الشرق", 35.3359, 40.1408, "في الشرق على نهر الفرات قرب الحدود العراقية، أراضٍ زراعية ضيقة على ضفاف النهر تحيط بها البادية.", "زراعة على ضفاف النهر وتربية المواشي وأنشطة نفطية.", "لماذا يتركز الاستقرار على ضفاف النهر وليس في البادية؟"], ["الرقة", "الشرق", 35.9528, 39.0079, "على نهر الفرات شمال شرق وسط البلاد، وفيها سد الطبقة وبحيرة الأسد.", "زراعة مروية على الفرات وتوليد الكهرباء من السد.", "كيف غيّر السد حياة المنطقة وأنشطتها؟"], ["درعا", "الجنوب", 32.6189, 36.1021, "في الجنوب على الحدود مع الأردن، فيها سهل حوران البركاني الخصيب.", "زراعة الحبوب والخضار والأشجار المثمرة.", "ما أثر التربة البركانية في خصوبة السهل؟"], ["السويداء", "الجنوب", 32.7089, 36.5663, "في الجنوب، مرتفعات بركانية تُعرف بجبل العرب وأمطارها أوفر من محيطها.", "زراعة العنب والتفاح والحبوب.", "لماذا تنجح زراعة العنب والتفاح في المرتفعات؟"], ["القنيطرة", "الجنوب", 33.126, 35.824, "في أقصى الجنوب الغربي، تتصل بهضبة الجولان وجبل الشيخ، وتتميز بمرتفعات وهضاب ومراعٍ.", "رعي وزراعة تناسب المرتفعات.", "كيف يؤثر الارتفاع عن سطح البحر في حرارة المنطقة؟"]];
const REGIONS=['الكل','دمشق وريفها','الساحل','الوسط','الشمال','الشرق','الجنوب'];
let map=null,ready=false,markers=[],region='الكل',query='',score={ok:0,n:0};
const norm=s=>String(s).replace(/[\u064B-\u065F\u0670]/g,'').replace(/[إأآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').toLowerCase();
const visible=()=>GOV.map((g,i)=>[g,i]).filter(x=>(region==='الكل'||x[0][1]===region)&&(!query||norm(x[0][0]+' '+x[0][4]+' '+x[0][5]).includes(query)));
function drawMarkers(){
 if(!map||!window.L)return;
 markers.forEach(m=>map.removeLayer(m));
 const vis=visible();
 markers=vis.map(x=>{const g=x[0],m=L.circleMarker([g[2],g[3]],{radius:9,color:'#8a5a12',weight:2,fillColor:'#C98B2B',fillOpacity:.85}).bindPopup('<strong>'+g[0]+'</strong><br>'+g[1]);m._gi=x[1];m.on('click',()=>focusCard(x[1]));m.addTo(map);return m;});
 if(vis.length>1)map.fitBounds(L.latLngBounds(vis.map(x=>[x[0][2],x[0][3]])),{padding:[24,24],maxZoom:8});
 else if(vis.length===1)map.setView([vis[0][0][2],vis[0][0][3]],8);
}
function renderList(){
 const vis=visible(),box=$('#atlasList'),cnt=$('#atlasCount');if(!box)return;
 box.innerHTML=vis.length?vis.map(x=>{const g=x[0];return '<article class="card atlas-card" data-gov="'+x[1]+'"><div class="card-title"><h3>'+g[0]+'</h3><span class="tag">'+g[1]+'</span></div><p>'+g[4]+'</p><p class="map-note"><strong>الأنشطة:</strong> '+g[5]+'</p><p class="map-note"><strong>فكّر:</strong> '+g[6]+'</p><button class="btn ghost small" type="button" data-focus="'+x[1]+'">عرض على الخريطة</button></article>';}).join(''):'<div class="empty">لا توجد محافظات مطابقة.</div>';
 if(cnt)cnt.textContent=vis.length+' من '+GOV.length;
 drawMarkers();
}
function focusCard(i){
 document.querySelectorAll('.atlas-card').forEach(c=>c.classList.toggle('is-focus',c.dataset.gov==String(i)));
 const c=document.querySelector('.atlas-card[data-gov="'+i+'"]');if(c&&c.scrollIntoView)c.scrollIntoView({block:'nearest',behavior:'smooth'});
}
function initMap(){
 if(ready)return;const el=$('#atlasMap');if(!el)return;
 if(!window.L){el.innerHTML='<div class="map-fallback" role="alert"><strong>تعذّر تحميل الخريطة</strong><p>تحتاج الخرائط إلى اتصال بالإنترنت. تحقق من الاتصال ثم أعد المحاولة.</p><button class="btn small" type="button" data-reload>إعادة المحاولة</button></div>';return;}
 map=L.map('atlasMap',{preferCanvas:true}).setView([35,38.5],6);
 L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a>'}).addTo(map);
 ready=true;drawMarkers();setTimeout(()=>{if(map)map.invalidateSize({pan:false});},120);
}
function quizNext(){
 const box=$('#atlasQuiz'),i=Math.floor(Math.random()*GOV.length),opts=[i];
 while(opts.length<4){const j=Math.floor(Math.random()*GOV.length);if(!opts.includes(j))opts.push(j);}
 opts.sort(()=>Math.random()-.5);box.dataset.answer=i;
 box.innerHTML='<div class="card-title"><h3>أي محافظة هذه؟</h3><span class="tag">'+score.ok+' / '+score.n+'</span></div><p>'+GOV[i][4]+'</p><div class="atlas-quiz-opts">'+opts.map(j=>'<button type="button" data-ans="'+j+'">'+GOV[j][0]+'</button>').join('')+'</div><p class="map-note" id="atlasQuizMsg" role="status" aria-live="polite"></p>';
}
function answer(b){
 const box=$('#atlasQuiz'),right=+box.dataset.answer,pick=+b.dataset.ans;if(box.dataset.done==='1'&&box.dataset.round===box.dataset.answer)return;
 box.dataset.done='1';box.dataset.round=box.dataset.answer;score.n++;if(pick===right)score.ok++;
 box.querySelectorAll('[data-ans]').forEach(x=>{x.disabled=true;if(+x.dataset.ans===right)x.classList.add('ok');else if(x===b)x.classList.add('no');});
 $('#atlasQuizMsg').innerHTML=(pick===right?'إجابة صحيحة. ':'الإجابة الصحيحة: '+GOV[right][0]+'. ')+GOV[right][6]+' <button class="btn small" type="button" data-next>التالي</button>';
 box.querySelector('.tag').textContent=score.ok+' / '+score.n;
}
function init(){
 const chips=$('#atlasChips');if(!chips)return;
 chips.innerHTML=REGIONS.map(r=>'<button type="button" class="atlas-chip" data-region="'+r+'" aria-pressed="'+(r===region)+'">'+r+'</button>').join('');
 chips.addEventListener('click',e=>{const b=e.target.closest('[data-region]');if(!b)return;region=b.dataset.region;chips.querySelectorAll('.atlas-chip').forEach(c=>c.setAttribute('aria-pressed',String(c===b)));renderList();});
 $('#atlasSearch').addEventListener('input',e=>{query=norm(e.target.value.trim());renderList();});
 $('#atlasQuizBtn').addEventListener('click',()=>{const q=$('#atlasQuiz');q.hidden=!q.hidden;if(!q.hidden){q.dataset.done='0';quizNext();}});
 $('#view-atlas').addEventListener('click',e=>{
  const f=e.target.closest('[data-focus]');if(f){const i=+f.dataset.focus;focusCard(i);if(map){map.flyTo([GOV[i][2],GOV[i][3]],8);const m=markers.find(x=>x._gi===i);if(m)m.openPopup();}return;}
  const a=e.target.closest('[data-ans]');if(a)return answer(a);
  if(e.target.closest('[data-next]')){$('#atlasQuiz').dataset.done='0';quizNext();}
 });
 renderList();
}
const prev=window.navigate;
if(typeof prev==='function')window.navigate=function(v){const r=prev.apply(this,arguments);if(v==='atlas')setTimeout(initMap,80);return r;};
document.addEventListener('DOMContentLoaded',init);
})();
