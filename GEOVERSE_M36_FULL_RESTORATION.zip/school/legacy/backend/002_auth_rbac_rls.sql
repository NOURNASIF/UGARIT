-- UGARIT v1.49: identity, session lifecycle, and tenant-scoped policies.
-- Apply as schema owner; run the API with a separate least-privilege DB role.
BEGIN;
CREATE TABLE IF NOT EXISTS auth_credentials (
  user_id uuid PRIMARY KEY REFERENCES user_profiles(id) ON DELETE CASCADE,
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  last_login_at timestamptz,
  password_changed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (email=lower(email))
);
CREATE TABLE IF NOT EXISTS auth_refresh_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
  token_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_refresh_user_active ON auth_refresh_sessions(user_id,expires_at) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_credentials_email ON auth_credentials(email);
-- Narrow SECURITY DEFINER lookup functions let the API authenticate without granting
-- broad direct access to profile rows. Keep the function owner as the schema owner.
CREATE OR REPLACE FUNCTION ugarit_auth_lookup(p_email text)
RETURNS TABLE(id uuid, organization_id uuid, full_name text, role text, status text, password_hash text)
LANGUAGE sql SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT p.id,p.organization_id,p.full_name,p.role,p.status,c.password_hash
 FROM auth_credentials c JOIN user_profiles p ON p.id=c.user_id WHERE c.email=lower(p_email) LIMIT 1
$$;

CREATE OR REPLACE FUNCTION ugarit_register_student(p_full_name text,p_email text,p_password_hash text)
RETURNS TABLE(user_id uuid, account_status text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE new_id uuid;
BEGIN
 INSERT INTO user_profiles(id,full_name,role,status) VALUES(gen_random_uuid(),trim(p_full_name),'student','pending') RETURNING id INTO new_id;
 INSERT INTO auth_credentials(user_id,email,password_hash) VALUES(new_id,lower(trim(p_email)),p_password_hash);
 RETURN QUERY SELECT new_id,'pending'::text;
END;
$$;
REVOKE ALL ON FUNCTION ugarit_register_student(text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION ugarit_profile_lookup(p_user_id uuid)
RETURNS TABLE(id uuid, organization_id uuid, full_name text, role text, status text)
LANGUAGE sql SECURITY DEFINER SET search_path=public,pg_temp AS $$
 SELECT p.id,p.organization_id,p.full_name,p.role,p.status FROM user_profiles p WHERE p.id=p_user_id LIMIT 1
$$;
REVOKE ALL ON FUNCTION ugarit_auth_lookup(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION ugarit_register_student(text,text,text) FROM PUBLIC;
REVOKE ALL ON FUNCTION ugarit_profile_lookup(uuid) FROM PUBLIC;
-- Grant EXECUTE to the dedicated API database role during deployment.
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessment_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS profile_self_or_org_admin ON user_profiles;
CREATE POLICY profile_self_or_org_admin ON user_profiles FOR SELECT USING (
 id = NULLIF(current_setting('app.user_id',true),'')::uuid OR
 (organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid AND
  current_setting('app.user_role',true) IN ('school_admin','directorate_admin','platform_admin')) OR
 current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS profile_admin_update ON user_profiles;
CREATE POLICY profile_admin_update ON user_profiles FOR UPDATE USING (
 (organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid AND
  current_setting('app.user_role',true) IN ('school_admin','directorate_admin')) OR
 current_setting('app.user_role',true)='platform_admin'
) WITH CHECK (
 (organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid AND
 current_setting('app.user_role',true) IN ('school_admin','directorate_admin')) OR
 current_setting('app.user_role',true)='platform_admin'
);
DROP POLICY IF EXISTS classes_org_read ON classes;
CREATE POLICY classes_org_read ON classes FOR SELECT USING (
 organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid
);
DROP POLICY IF EXISTS classes_staff_write ON classes;
CREATE POLICY classes_staff_write ON classes FOR ALL USING (
 organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid AND
 current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin')
) WITH CHECK (
 organization_id = NULLIF(current_setting('app.organization_id',true),'')::uuid AND
 current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin')
);
DROP POLICY IF EXISTS enrollments_org_read ON enrollments;
CREATE POLICY enrollments_org_read ON enrollments FOR SELECT USING (
 student_id=NULLIF(current_setting('app.user_id',true),'')::uuid OR
 class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid)
);
DROP POLICY IF EXISTS enrollments_staff_write ON enrollments;
CREATE POLICY enrollments_staff_write ON enrollments FOR ALL USING (
 current_setting('app.user_role',true) IN ('school_admin','directorate_admin','platform_admin') AND
 class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid)
) WITH CHECK (
 current_setting('app.user_role',true) IN ('school_admin','directorate_admin','platform_admin') AND
 class_id IN (SELECT id FROM classes WHERE organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid)
);
DROP POLICY IF EXISTS resources_published_or_staff ON learning_resources;
CREATE POLICY resources_published_or_staff ON learning_resources FOR SELECT USING (
 publication_status='published' OR
 (organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid AND
  current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin'))
);
DROP POLICY IF EXISTS resources_staff_write ON learning_resources;
CREATE POLICY resources_staff_write ON learning_resources FOR ALL USING (
 organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid AND
 current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin')
) WITH CHECK (
 organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid AND
 current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin')
);
DROP POLICY IF EXISTS attempts_owner_or_staff ON assessment_attempts;
CREATE POLICY attempts_owner_or_staff ON assessment_attempts FOR SELECT USING (
 student_id=NULLIF(current_setting('app.user_id',true),'')::uuid OR
 current_setting('app.user_role',true) IN ('teacher','school_admin','directorate_admin','platform_admin')
);
DROP POLICY IF EXISTS attempts_student_insert ON assessment_attempts;
CREATE POLICY attempts_student_insert ON assessment_attempts FOR INSERT WITH CHECK (
 student_id=NULLIF(current_setting('app.user_id',true),'')::uuid
);
DROP POLICY IF EXISTS audit_org_read ON audit_logs;
CREATE POLICY audit_org_read ON audit_logs FOR SELECT USING (
 current_setting('app.user_role',true) IN ('school_admin','directorate_admin','platform_admin') AND
 (organization_id=NULLIF(current_setting('app.organization_id',true),'')::uuid OR current_setting('app.user_role',true)='platform_admin')
);
-- auth_credentials and auth_refresh_sessions are accessed only by the API service role.
-- Do not grant these tables to anon/authenticated browser roles.
COMMIT;
