'use strict';
const http=require('node:http');
const crypto=require('node:crypto');
const {Pool}=require('pg');
const {signAccessToken,verifyAccessToken,hashPassword,verifyPassword,randomToken,sha256}=require('./security');
const required=['DATABASE_URL','JWT_SECRET'];for(const k of required)if(!process.env[k]){console.error(`Missing required environment variable: ${k}`);process.exit(1);}
if(process.env.JWT_SECRET.length<32){console.error('JWT_SECRET must contain at least 32 characters');process.exit(1);}
const PORT=Number(process.env.PORT||8080),ACCESS_TTL=Number(process.env.ACCESS_TOKEN_TTL_SECONDS||900),REFRESH_DAYS=Number(process.env.REFRESH_TOKEN_TTL_DAYS||7);
const allowedOrigins=(process.env.CORS_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean);
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==='true'?{rejectUnauthorized:true}:undefined,max:10,idleTimeoutMillis:30000,connectionTimeoutMillis:5000});
const buckets=new Map();
function rateLimit(key,limit=12,windowMs=60000){const now=Date.now();if(buckets.size>10000){for(const [k,v] of buckets)if(v.until<now)buckets.delete(k);}const b=buckets.get(key)||{n:0,until:now+windowMs};if(now>b.until){b.n=0;b.until=now+windowMs;}b.n++;buckets.set(key,b);return b.n<=limit;}
function send(res,status,data,headers={}){const body=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Content-Length':Buffer.byteLength(body),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",...headers});res.end(body);}
function cookie(name,value,maxAge){return `${name}=${value}; HttpOnly; Secure; SameSite=None; Path=/api/v1/auth; Max-Age=${maxAge}`;}
function parseCookies(req){return Object.fromEntries(String(req.headers.cookie||'').split(';').map(x=>x.trim().split(/=(.*)/s).slice(0,2)).filter(x=>x.length===2));}
async function body(req){let raw='';for await(const c of req){raw+=c;if(raw.length>65536)throw Object.assign(new Error('payload_too_large'),{status:413});}try{return raw?JSON.parse(raw):{};}catch(_){throw Object.assign(new Error('invalid_json'),{status:400});}}
function validEmail(v){return typeof v==='string'&&v.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);}
function validPassword(v){return typeof v==='string'&&v.length>=10&&v.length<=128;}
async function auth(req){const h=String(req.headers.authorization||'');if(!h.startsWith('Bearer '))throw Object.assign(new Error('unauthorized'),{status:401});let claims;try{claims=verifyAccessToken(h.slice(7),process.env.JWT_SECRET);}catch(_){throw Object.assign(new Error('invalid_or_expired_token'),{status:401});}
 const {rows}=await pool.query('SELECT id, organization_id, full_name, role, status FROM ugarit_profile_lookup($1)',[claims.sub]);const user=rows[0];if(!user||user.status!=='active')throw Object.assign(new Error('account_not_active'),{status:403});return user;}
function roles(...allowed){return user=>{if(!allowed.includes(user.role))throw Object.assign(new Error('forbidden'),{status:403});};}
async function withTenant(user,fn){const c=await pool.connect();try{await c.query('BEGIN');await c.query("SELECT set_config('app.user_id',$1,true), set_config('app.organization_id',$2,true), set_config('app.user_role',$3,true)",[user.id,user.organization_id||'',user.role]);const result=await fn(c);await c.query('COMMIT');return result;}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}}
async function route(req,res,url){const path=url.pathname.replace(/\/$/,'')||'/',method=req.method;
 if(method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS','Access-Control-Allow-Headers':'Content-Type,Authorization','Access-Control-Max-Age':'600'});return res.end();}
 if(path==='/api/v1/health'&&method==='GET'){try{await pool.query('SELECT 1');return send(res,200,{status:'ok',service:'UGARIT API',database:'connected',version:'1.0.0'});}catch(_){return send(res,503,{status:'degraded',service:'UGARIT API',database:'unavailable'});}}
 if(path==='/api/v1/auth/register'&&method==='POST'){
  if(!rateLimit(`register:${req.socket.remoteAddress}`,5))return send(res,429,{error:'rate_limited'});
  const b=await body(req),fullName=String(b.fullName||'').trim(),email=String(b.email||'').trim().toLowerCase();
  if(fullName.length<2||fullName.length>160||!validEmail(email)||!validPassword(b.password))return send(res,400,{error:'invalid_registration_data',message:'تحقق من الاسم والبريد وكلمة المرور (10 أحرف على الأقل).'});
  const passwordHash=await hashPassword(b.password);
  try{await pool.query('SELECT * FROM ugarit_register_student($1,$2,$3)',[fullName,email,passwordHash]);return send(res,201,{status:'pending_approval',message:'تم استلام طلب الحساب. يحتاج تفعيل مسؤول المؤسسة قبل تسجيل الدخول.'});}
  catch(e){if(e.code==='23505')return send(res,409,{error:'email_already_registered'});throw e;}
 }
 if(path==='/api/v1/auth/login'&&method==='POST'){
  if(!rateLimit(`login:${req.socket.remoteAddress}`,10))return send(res,429,{error:'rate_limited'});
  const b=await body(req),email=String(b.email||'').trim().toLowerCase();if(!validEmail(email)||typeof b.password!=='string')return send(res,400,{error:'invalid_credentials'});
  const q=await pool.query('SELECT * FROM ugarit_auth_lookup($1)',[email]);const row=q.rows[0];
  if(!row||!(await verifyPassword(b.password,row.password_hash)))return send(res,401,{error:'invalid_credentials'});
  if(row.status!=='active')return send(res,403,{error:'account_pending_or_suspended',message:'الحساب بانتظار التفعيل أو موقوف.'});
  const token=signAccessToken({sub:row.id,role:row.role,org:row.organization_id},process.env.JWT_SECRET,ACCESS_TTL),refresh=randomToken();
  await pool.query('INSERT INTO auth_refresh_sessions(user_id,token_hash,expires_at) VALUES($1,$2,now()+($3::text||\' days\')::interval)',[row.id,sha256(refresh),REFRESH_DAYS]);
  await pool.query('UPDATE auth_credentials SET last_login_at=now() WHERE user_id=$1',[row.id]);
  return send(res,200,{accessToken:token,expiresIn:ACCESS_TTL,user:{id:row.id,fullName:row.full_name,role:row.role,organizationId:row.organization_id}}, {'Set-Cookie':cookie('ugarit_refresh',refresh,REFRESH_DAYS*86400)});
 }
 if(path==='/api/v1/auth/refresh'&&method==='POST'){
  if(!req.headers.origin||!allowedOrigins.includes(req.headers.origin))return send(res,403,{error:'origin_not_allowed'});
  const token=parseCookies(req).ugarit_refresh;if(!token)return send(res,401,{error:'refresh_required'});
  const q=await pool.query('SELECT s.id,s.user_id,p.role,p.organization_id,p.status FROM auth_refresh_sessions s CROSS JOIN LATERAL ugarit_profile_lookup(s.user_id) p WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now()',[sha256(token)]);const row=q.rows[0];if(!row||row.status!=='active')return send(res,401,{error:'invalid_refresh'});
  await pool.query('UPDATE auth_refresh_sessions SET revoked_at=now() WHERE id=$1',[row.id]);const next=randomToken();await pool.query('INSERT INTO auth_refresh_sessions(user_id,token_hash,expires_at) VALUES($1,$2,now()+($3::text||\' days\')::interval)',[row.user_id,sha256(next),REFRESH_DAYS]);const accessToken=signAccessToken({sub:row.user_id,role:row.role,org:row.organization_id},process.env.JWT_SECRET,ACCESS_TTL);return send(res,200,{accessToken,expiresIn:ACCESS_TTL},{'Set-Cookie':cookie('ugarit_refresh',next,REFRESH_DAYS*86400)});
 }
 if(path==='/api/v1/auth/logout'&&method==='POST'){
  if(!req.headers.origin||!allowedOrigins.includes(req.headers.origin))return send(res,403,{error:'origin_not_allowed'});
  const token=parseCookies(req).ugarit_refresh;if(token)await pool.query('UPDATE auth_refresh_sessions SET revoked_at=now() WHERE token_hash=$1',[sha256(token)]);return send(res,200,{status:'ok'},{'Set-Cookie':cookie('ugarit_refresh','',0)});
 }
 if(path==='/api/v1/auth/me'&&method==='GET'){const u=await auth(req);return send(res,200,{user:{id:u.id,fullName:u.full_name,role:u.role,organizationId:u.organization_id}});}
 if(path==='/api/v1/resources'&&method==='GET'){const grade=url.searchParams.get('grade');const q=await pool.query("SELECT id,title,subject,grade_level,resource_type,content_uri,content_json,updated_at FROM learning_resources WHERE publication_status='published' AND ($1::text IS NULL OR grade_level=$1) ORDER BY updated_at DESC LIMIT 100",[grade]);return send(res,200,{items:q.rows});}
 if(path==='/api/v1/classes'&&method==='GET'){const u=await auth(req);const result=await withTenant(u,async c=>{if(u.role==='student')return (await c.query('SELECT cl.id,cl.name,cl.grade_level,cl.academic_year FROM classes cl JOIN enrollments e ON e.class_id=cl.id WHERE e.student_id=$1 AND e.status=\'active\'',[u.id])).rows;if(u.role==='teacher')return (await c.query('SELECT id,name,grade_level,academic_year,status FROM classes WHERE teacher_id=$1 ORDER BY created_at DESC LIMIT 100',[u.id])).rows;return (await c.query('SELECT id,name,grade_level,academic_year,status FROM classes ORDER BY created_at DESC LIMIT 100')).rows;});return send(res,200,{items:result});}
 if(path==='/api/v1/classes'&&method==='POST'){const u=await auth(req);roles('teacher','school_admin','directorate_admin','platform_admin')(u);const b=await body(req);const gradeLevel=String(b.gradeLevel||'');if(typeof b.name!=='string'||b.name.trim().length<2||b.name.length>120||!/^([1-9]|1[0-2])$/.test(gradeLevel)||typeof b.academicYear!=='string'||b.academicYear.length>30)return send(res,400,{error:'invalid_class',message:'اسم الصف مطلوب، ومستوى الصف يجب أن يكون رقماً من 1 إلى 12.'});const organizationId=u.role==='platform_admin'?String(b.organizationId||''):u.organization_id;if(!/^[0-9a-f-]{36}$/i.test(organizationId))return send(res,400,{error:'organization_required'});const result=await withTenant(u,async c=>{if(u.role==='platform_admin'){const org=(await c.query("SELECT id FROM organizations WHERE id=$1 AND status='active'",[organizationId])).rows[0];if(!org)throw Object.assign(new Error('active_organization_not_found'),{status:404});}return (await c.query('INSERT INTO classes(organization_id,name,grade_level,academic_year,teacher_id) VALUES($1,$2,$3,$4,$5) RETURNING id,name,grade_level,academic_year,teacher_id,status',[organizationId,b.name.trim(),gradeLevel,b.academicYear,u.role==='teacher'?u.id:null])).rows[0];});return send(res,201,{item:result});}
 // M7: authenticated, class-scoped assessment reporting. Raw answer sheets are never accepted.
 const classAttemptsMatch=path.match(/^\/api\/v1\/classes\/([0-9a-f-]{36})\/assessment-attempts$/i);
 if(classAttemptsMatch&&method==='POST'){
  const u=await auth(req);roles('student')(u);if(!rateLimit(`assessment:${u.id}`,60,60000))return send(res,429,{error:'rate_limited'});const classId=classAttemptsMatch[1];const b=await body(req);
  const score=Number(b.score),maxScore=Number(b.maxScore),duration=Number(b.durationSeconds||0),topic=String(b.topic||'').trim();
  if(!Number.isFinite(score)||!Number.isFinite(maxScore)||maxScore<=0||maxScore>500||score<0||score>maxScore||!topic||topic.length>100||!Number.isInteger(duration)||duration<0||duration>14400)return send(res,400,{error:'invalid_attempt_data'});
  const cleanSummary=(items,key)=>{if(!Array.isArray(items)||items.length>20)return null;const out=[];for(const item of items){if(!item||typeof item[key]!=='string'||item[key].length>80)return null;const total=Number(item.total),correct=Number(item.correct);if(!Number.isInteger(total)||!Number.isInteger(correct)||total<1||total>500||correct<0||correct>total)return null;out.push({[key]:item[key],correct,total});}return out;};
  const skills=cleanSummary(b.skills,'skill'),topics=cleanSummary(b.topics,'topic');if(skills===null||topics===null)return send(res,400,{error:'invalid_summary'});
  const startedAt=b.startedAt?new Date(b.startedAt):new Date();if(Number.isNaN(startedAt.getTime())||startedAt.getTime()>Date.now()+60000||startedAt.getTime()<Date.now()-7*86400000)return send(res,400,{error:'invalid_started_at'});
  const result=await withTenant(u,async c=>{
   const enrolled=await c.query("SELECT cl.id,cl.grade_level FROM classes cl JOIN enrollments e ON e.class_id=cl.id WHERE cl.id=$1 AND e.student_id=$2 AND cl.organization_id=$3 AND e.status='active' AND cl.status='active' LIMIT 1",[classId,u.id,u.organization_id]);
   if(!enrolled.rows[0])throw Object.assign(new Error('class_enrollment_required'),{status:403});
   const grade=Number(enrolled.rows[0].grade_level);if(!Number.isInteger(grade)||grade<1||grade>12)throw Object.assign(new Error('class_grade_not_supported'),{status:409});
   return (await c.query(`INSERT INTO assessment_attempts(student_id,class_id,grade_level,topic,score,max_score,percent,duration_seconds,skills_json,topics_json,answers_json,started_at,submitted_at)
    VALUES($1,$2,$3,$4,$5,$6,round(($5::numeric/$6::numeric)*100,2),$7,$8::jsonb,$9::jsonb,'{}'::jsonb,$10,now())
    RETURNING id,grade_level,topic,score,max_score,percent,duration_seconds,started_at,submitted_at`,[u.id,classId,grade,topic,score,maxScore,duration,JSON.stringify(skills),JSON.stringify(topics),startedAt.toISOString()])).rows[0];
  });
  return send(res,201,{item:result,message:'تم حفظ نتيجة الاختبار في سجل الصف.'});
 }
 if(classAttemptsMatch&&method==='GET'){
  const u=await auth(req);roles('teacher','school_admin','directorate_admin')(u);const classId=classAttemptsMatch[1];
  const rows=await withTenant(u,async c=>{
   const allowed=await c.query(`SELECT id FROM classes WHERE id=$1 AND ((teacher_id=$2 AND $3='teacher') OR (organization_id=$4 AND $3 IN ('school_admin','directorate_admin'))) LIMIT 1`,[classId,u.id,u.role,u.organization_id]);
   if(!allowed.rows[0])throw Object.assign(new Error('class_access_denied'),{status:403});
   return (await c.query(`SELECT a.id,a.grade_level,a.topic,a.score,a.max_score,a.percent,a.duration_seconds,a.skills_json,a.topics_json,a.started_at,a.submitted_at,p.full_name AS student_name
    FROM assessment_attempts a JOIN user_profiles p ON p.id=a.student_id WHERE a.class_id=$1 ORDER BY a.submitted_at DESC LIMIT 500`,[classId])).rows;
  });
  return send(res,200,{items:rows,scope:'authorized_class',count:rows.length});
 }
 // M9: institutional class administration and enrollment management.
 const classAdminMatch=path.match(/^\/api\/v1\/classes\/([0-9a-f-]{36})$/i);
 if(classAdminMatch&&method==='PATCH'){
  const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const b=await body(req);const classId=classAdminMatch[1];
  const name=b.name===undefined?null:String(b.name).trim(),year=b.academicYear===undefined?null:String(b.academicYear).trim(),status=b.status===undefined?null:String(b.status),teacherId=b.teacherId===undefined?undefined:(b.teacherId===null||b.teacherId===''?null:String(b.teacherId));
  if(name!==null&&(name.length<2||name.length>120)||year!==null&&(year.length<1||year.length>30)||status!==null&&!['active','archived'].includes(status)||teacherId!==undefined&&teacherId!==null&&!/^[0-9a-f-]{36}$/i.test(teacherId))return send(res,400,{error:'invalid_class_update'});
  const updated=await withTenant(u,async c=>{
   const current=(await c.query('SELECT id,organization_id FROM classes WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2) FOR UPDATE',[classId,u.role==='platform_admin'?null:u.organization_id])).rows[0];if(!current)return null;
   if(teacherId){const t=(await c.query("SELECT id FROM user_profiles WHERE id=$1 AND organization_id=$2 AND role='teacher' AND status='active'",[teacherId,current.organization_id])).rows[0];if(!t)throw Object.assign(new Error('teacher_not_active_in_organization'),{status:409});}
   return (await c.query(`UPDATE classes SET name=COALESCE($1,name),academic_year=COALESCE($2,academic_year),status=COALESCE($3,status),teacher_id=CASE WHEN $4 THEN $5::uuid ELSE teacher_id END WHERE id=$6 RETURNING id,name,grade_level,academic_year,teacher_id,status`,[name,year,status,teacherId!==undefined,teacherId===undefined?null:teacherId,classId])).rows[0];
  });if(!updated)return send(res,404,{error:'class_not_found'});return send(res,200,{item:updated});
 }
 const rosterMatch=path.match(/^\/api\/v1\/classes\/([0-9a-f-]{36})\/enrollments$/i);
 if(rosterMatch&&method==='GET'){
  const u=await auth(req);roles('teacher','school_admin','directorate_admin','platform_admin')(u);const classId=rosterMatch[1];
  const rows=await withTenant(u,async c=>{
   const allowed=(await c.query("SELECT id FROM classes WHERE id=$1 AND ((teacher_id=$2 AND $3='teacher') OR (organization_id=$4 AND $3 IN ('school_admin','directorate_admin')) OR $3='platform_admin')",[classId,u.id,u.role,u.organization_id])).rows[0];if(!allowed)throw Object.assign(new Error('class_access_denied'),{status:403});
   return (await c.query(`SELECT p.id,p.full_name,p.status,e.status AS enrollment_status,e.enrolled_at FROM enrollments e JOIN user_profiles p ON p.id=e.student_id WHERE e.class_id=$1 ORDER BY p.full_name LIMIT 500`,[classId])).rows;
  });return send(res,200,{items:rows,count:rows.length,scope:'authorized_class_roster'});
 }
 if(rosterMatch&&method==='POST'){
  const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const b=await body(req);const classId=rosterMatch[1];
  if(Array.isArray(b.emails)){
   const emails=[...new Set(b.emails.map(x=>String(x||'').trim().toLowerCase()).filter(Boolean))];
   if(!emails.length||emails.length>100||emails.some(x=>!validEmail(x)))return send(res,400,{error:'invalid_bulk_email_list',message:'أرسل من 1 إلى 100 بريداً إلكترونياً صالحاً.'});
   const result=await withTenant(u,async c=>{
    const cl=(await c.query('SELECT id,organization_id,status FROM classes WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2) FOR UPDATE',[classId,u.role==='platform_admin'?null:u.organization_id])).rows[0];if(!cl)throw Object.assign(new Error('class_not_found'),{status:404});if(cl.status!=='active')throw Object.assign(new Error('class_not_active'),{status:409});
    const added=[],rejected=[];
    for(const email of emails){
     const student=(await c.query("SELECT p.id FROM auth_credentials a JOIN user_profiles p ON p.id=a.user_id WHERE a.email=$1 AND p.organization_id=$2 AND p.role='student' AND p.status='active'",[email,cl.organization_id])).rows[0];
     if(!student){rejected.push({email,reason:'student_not_found_or_inactive_in_organization'});continue;}
     const row=(await c.query(`INSERT INTO enrollments(class_id,student_id,status) VALUES($1,$2,'active') ON CONFLICT(class_id,student_id) DO UPDATE SET status='active',enrolled_at=now() RETURNING student_id,status`,[classId,student.id])).rows[0];added.push({email,studentId:row.student_id,status:row.status});
    }
    return {added,rejected,received:emails.length};
   });return send(res,200,{item:result,message:`تم تسجيل ${result.added.length} طالباً، وتعذر تسجيل ${result.rejected.length}.`});
  }
  const studentId=String(b.studentId||'');if(!/^[0-9a-f-]{36}$/i.test(studentId))return send(res,400,{error:'invalid_student_id'});
  const item=await withTenant(u,async c=>{
   const cl=(await c.query('SELECT id,organization_id,status FROM classes WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2) FOR UPDATE',[classId,u.role==='platform_admin'?null:u.organization_id])).rows[0];if(!cl)throw Object.assign(new Error('class_not_found'),{status:404});if(cl.status!=='active')throw Object.assign(new Error('class_not_active'),{status:409});
   const student=(await c.query("SELECT id FROM user_profiles WHERE id=$1 AND organization_id=$2 AND role='student' AND status='active'",[studentId,cl.organization_id])).rows[0];if(!student)throw Object.assign(new Error('active_student_not_found_in_organization'),{status:404});
   return (await c.query(`INSERT INTO enrollments(class_id,student_id,status) VALUES($1,$2,'active') ON CONFLICT(class_id,student_id) DO UPDATE SET status='active',enrolled_at=now() RETURNING class_id,student_id,status,enrolled_at`,[classId,studentId])).rows[0];
  });return send(res,201,{item,message:'تم تسجيل الطالب في الصف.'});
 }
 const withdrawMatch=path.match(/^\/api\/v1\/classes\/([0-9a-f-]{36})\/enrollments\/([0-9a-f-]{36})$/i);
 if(withdrawMatch&&method==='DELETE'){
  const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const [,classId,studentId]=withdrawMatch;
  const result=await withTenant(u,async c=>{
   const cl=(await c.query('SELECT id FROM classes WHERE id=$1 AND ($2::uuid IS NULL OR organization_id=$2)',[classId,u.role==='platform_admin'?null:u.organization_id])).rows[0];if(!cl)throw Object.assign(new Error('class_not_found'),{status:404});
   return (await c.query("UPDATE enrollments SET status='withdrawn' WHERE class_id=$1 AND student_id=$2 RETURNING class_id,student_id,status",[classId,studentId])).rows[0];
  });if(!result)return send(res,404,{error:'enrollment_not_found'});return send(res,200,{item:result,message:'تم إيقاف تسجيل الطالب في هذا الصف.'});
 }
 if(path==='/api/v1/admin/organizations'&&method==='GET'){
  const u=await auth(req);roles('platform_admin')(u);const rows=(await pool.query("SELECT id,name,organization_type FROM organizations WHERE status='active' ORDER BY name LIMIT 500")).rows;return send(res,200,{items:rows});
 }
 if(path==='/api/v1/admin/users'&&method==='POST'){
  const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const b=await body(req);const fullName=String(b.fullName||'').trim(),email=String(b.email||'').trim().toLowerCase(),role=String(b.role||'');
  const allowed=u.role==='school_admin'||u.role==='directorate_admin'?['teacher']:['teacher','school_admin','directorate_admin','researcher'];
  if(!allowed.includes(role)||fullName.length<2||fullName.length>160||!validEmail(email)||!validPassword(b.password))return send(res,400,{error:'invalid_staff_account',message:'تحقق من الاسم والبريد والدور وكلمة المرور (10 أحرف على الأقل).'});
  const organizationId=u.role==='platform_admin'?String(b.organizationId||''):u.organization_id;if(!/^[0-9a-f-]{36}$/i.test(organizationId))return send(res,400,{error:'organization_required'});
  const passwordHash=await hashPassword(b.password),id=crypto.randomUUID();
  try{const user=await withTenant(u,async c=>{const org=(await c.query("SELECT id FROM organizations WHERE id=$1 AND status='active'",[organizationId])).rows[0];if(!org)throw Object.assign(new Error('active_organization_not_found'),{status:404});const profile=(await c.query("INSERT INTO user_profiles(id,organization_id,full_name,role,status) VALUES($1,$2,$3,$4,'active') RETURNING id,organization_id,full_name,role,status",[id,organizationId,fullName,role])).rows[0];await c.query('INSERT INTO auth_credentials(user_id,email,password_hash) VALUES($1,$2,$3)',[id,email,passwordHash]);return profile;});return send(res,201,{user,message:'تم إنشاء الحساب وتفعيله. سلّم بيانات الدخول لصاحب الحساب عبر قناة آمنة.'});}
  catch(e){if(e.code==='23505')return send(res,409,{error:'email_already_registered'});throw e;}
 }
 if(path==='/api/v1/admin/users'&&method==='GET'){const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const role=url.searchParams.get('role'),status=url.searchParams.get('status');if(role&&!['student','teacher','school_admin','directorate_admin','researcher'].includes(role)||status&&!['pending','active','suspended'].includes(status))return send(res,400,{error:'invalid_user_filter'});const rows=await withTenant(u,async c=>(await c.query('SELECT id,full_name,role,status,organization_id,created_at FROM user_profiles WHERE ($1::uuid IS NULL OR organization_id=$1) AND ($2::text IS NULL OR role=$2) AND ($3::text IS NULL OR status=$3) ORDER BY created_at DESC LIMIT 200',[u.role==='platform_admin'?null:u.organization_id,role,status])).rows);return send(res,200,{items:rows,count:rows.length});}
 const userStatusMatch=path.match(/^\/api\/v1\/admin\/users\/([0-9a-f-]{36})$/);
 if(userStatusMatch&&method==='PATCH'){const u=await auth(req);roles('school_admin','directorate_admin','platform_admin')(u);const b=await body(req);if(!['pending','active','suspended'].includes(b.status))return send(res,400,{error:'invalid_status'});const org=b.organizationId||null;if(org&&!/^[0-9a-f-]{36}$/i.test(org))return send(res,400,{error:'invalid_organization'});const updated=await withTenant(u,async c=>(await c.query('UPDATE user_profiles SET status=$1,organization_id=COALESCE($4::uuid,organization_id),updated_at=now() WHERE id=$2 AND ($3::uuid IS NULL OR organization_id=$3) RETURNING id,full_name,role,status,organization_id',[b.status,userStatusMatch[1],u.role==='platform_admin'?null:u.organization_id,org])).rows[0]);if(!updated)return send(res,404,{error:'user_not_found'});return send(res,200,{user:updated});}
 return send(res,404,{error:'not_found'});
}
const server=http.createServer(async(req,res)=>{const origin=req.headers.origin;if(origin&&allowedOrigins.includes(origin)){res.setHeader('Access-Control-Allow-Origin',origin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Credentials','true');}else if(origin&&allowedOrigins.length){return send(res,403,{error:'origin_not_allowed'});}try{await route(req,res,new URL(req.url,'http://localhost'));}catch(e){const status=e.status||500;if(status>=500)console.error({requestId:crypto.randomUUID(),error:e.message,code:e.code});send(res,status,{error:status>=500?'internal_error':e.message});}});
server.listen(PORT,()=>console.log(`UGARIT API listening on ${PORT}`));
process.on('SIGTERM',async()=>{server.close();await pool.end();process.exit(0);});
