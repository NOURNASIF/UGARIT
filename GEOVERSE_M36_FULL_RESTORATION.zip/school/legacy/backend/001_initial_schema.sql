-- UGARIT v1.38: PostgreSQL foundational schema.
-- Apply only after review by the deployment administrator. Never expose DB credentials to the browser.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE organizations (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 name text NOT NULL CHECK (length(trim(name)) BETWEEN 2 AND 200),
 organization_type text NOT NULL CHECK (organization_type IN ('ministry','directorate','school','university','research_center')),
 parent_id uuid REFERENCES organizations(id) ON DELETE RESTRICT,
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended')),
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE user_profiles (
 id uuid PRIMARY KEY, -- must equal the authenticated identity provider subject
 organization_id uuid REFERENCES organizations(id) ON DELETE RESTRICT,
 full_name text NOT NULL CHECK (length(trim(full_name)) BETWEEN 2 AND 160),
 role text NOT NULL CHECK (role IN ('student','teacher','school_admin','directorate_admin','platform_admin','researcher')),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended')),
 preferred_locale text NOT NULL DEFAULT 'ar', created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_profiles_org_role ON user_profiles(organization_id,role,status);
CREATE TABLE classes (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
 name text NOT NULL, grade_level text NOT NULL, academic_year text NOT NULL,
 teacher_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL, status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','archived')),
 created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(organization_id,name,academic_year)
);
CREATE TABLE enrollments (
 class_id uuid NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
 student_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE CASCADE,
 enrolled_at timestamptz NOT NULL DEFAULT now(), status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','withdrawn')),
 PRIMARY KEY(class_id,student_id)
);
CREATE TABLE learning_resources (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), organization_id uuid REFERENCES organizations(id) ON DELETE RESTRICT,
 title text NOT NULL, subject text NOT NULL DEFAULT 'geography', grade_level text,
 resource_type text NOT NULL CHECK(resource_type IN ('lesson','map','worksheet','video','dataset','reference')),
 content_uri text, content_json jsonb NOT NULL DEFAULT '{}'::jsonb,
 publication_status text NOT NULL DEFAULT 'draft' CHECK(publication_status IN ('draft','review','published','archived')),
 created_by uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_resources_subject_grade ON learning_resources(subject,grade_level,publication_status);
CREATE TABLE assessment_attempts (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), student_id uuid NOT NULL REFERENCES user_profiles(id) ON DELETE RESTRICT,
 resource_id uuid REFERENCES learning_resources(id) ON DELETE SET NULL,
 score numeric(7,2) CHECK(score IS NULL OR score>=0), max_score numeric(7,2) CHECK(max_score IS NULL OR max_score>0),
 answers_json jsonb NOT NULL DEFAULT '{}'::jsonb, started_at timestamptz NOT NULL DEFAULT now(), submitted_at timestamptz,
 CHECK(score IS NULL OR max_score IS NULL OR score<=max_score)
);
CREATE INDEX idx_attempts_student_date ON assessment_attempts(student_id,started_at DESC);
CREATE TABLE audit_logs (
 id bigserial PRIMARY KEY, actor_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
 organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL,
 action text NOT NULL, entity_type text NOT NULL, entity_id text,
 request_id text, metadata jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_org_date ON audit_logs(organization_id,created_at DESC);
-- SECURITY REQUIREMENT: enable RLS and add reviewed policies before any production use.
-- No permissive policies are intentionally created in this starter migration.
