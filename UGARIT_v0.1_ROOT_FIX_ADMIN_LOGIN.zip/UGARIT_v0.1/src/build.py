# يبني index.html مكتفياً بنفسه من ملفات المصدر في هذا المجلد: python3 src/build.py
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
read = lambda name: (ROOT / name).read_text(encoding="utf-8")

source = read("index.src.html")
replacements = {
    '<link rel="stylesheet" href="./css/styles.css">': '<style>\n' + read("css/styles.css") + '\n</style>',
    '<script src="./js/data.js"></script>': '<script>\n' + read("js/data.js") + '\n</script>',
    '<script src="./js/app.js"></script>': '<script>\n' + read("js/app.js") + '\n</script>',
    '<script src="./js/ux.js"></script>': '<script>\n' + read("js/ux.js") + '\n</script>',
    '<script src="./js/themes.js"></script>': '<script>\n' + read("js/themes.js") + '\n</script>',
    '<script src="./js/atlas.js"></script>': '<script>\n' + read("js/atlas.js") + '\n</script>',
}
for marker, replacement in replacements.items():
    count = source.count(marker)
    if count != 1:
        raise SystemExit(f"Build aborted: expected exactly one source marker, found {count}: {marker}")
    source = source.replace(marker, replacement)

required = [
    'id="ugaritAdminLoginForm"',
    'id="ugaritAdminDock"',
    'UGARIT_ADMIN_HANDLER_READY',
    'تعذر تحميل نظام دخول المدير',
    'admin-portal.js?v=0.1.12',
]
for token in required:
    if token not in source:
        raise SystemExit(f"Build aborted: required security/UI marker is missing: {token}")

output = PROJECT / "index.html"
output.write_text(source, encoding="utf-8")
print(f"Built {output.name} ({output.stat().st_size} bytes)")
