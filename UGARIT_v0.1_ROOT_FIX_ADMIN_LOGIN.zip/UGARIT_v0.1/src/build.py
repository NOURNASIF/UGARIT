# يبني index.html مكتفياً بنفسه من ملفات المصدر في هذا المجلد: python3 src/build.py
import os
h=os.path.dirname(os.path.abspath(__file__)); rd=lambda f:open(os.path.join(h,f),encoding="utf-8").read()
s=rd("index.src.html")
s=s.replace('<link rel="stylesheet" href="./css/styles.css">','<style>\n'+rd("css/styles.css")+'</style>')
s=s.replace('<script src="./js/data.js"></script>','<script>\n'+rd("js/data.js")+'</script>')
s=s.replace('<script src="./js/app.js"></script>','<script>\n'+rd("js/app.js")+'</script>')
s=s.replace('<script src="./js/ux.js"></script>','<script>\n'+rd("js/ux.js")+'</script>')
s=s.replace('<script src="./js/themes.js"></script>','<script>\n'+rd("js/themes.js")+'</script>')
s=s.replace('<script src="./js/atlas.js"></script>','<script>\n'+rd("js/atlas.js")+'</script>')
open(os.path.join(h,"..","index.html"),"w",encoding="utf-8").write(s); print("built index.html")
