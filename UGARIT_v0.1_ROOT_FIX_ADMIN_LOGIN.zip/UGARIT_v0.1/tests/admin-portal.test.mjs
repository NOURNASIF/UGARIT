import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { handler } from '../netlify/functions/admin-portal.mjs';

const envKeys = ['UGARIT_ADMIN_USERNAME', 'UGARIT_ADMIN_PASSWORD', 'UGARIT_ADMIN_SESSION_SECRET'];
const originalEnv = Object.fromEntries(envKeys.map(key => [key, process.env[key]]));
const testUsername = 'owner_test_user_01';
const testPassword = 'Test-Only-Password-Not-For-Production!';
const testSecret = 'test-only-session-secret-0123456789-ABCDEFG';
let issuedCookie = '';

before(() => {
  process.env.UGARIT_ADMIN_USERNAME = testUsername;
  process.env.UGARIT_ADMIN_PASSWORD = testPassword;
  process.env.UGARIT_ADMIN_SESSION_SECRET = testSecret;
});

after(() => {
  for (const key of envKeys) {
    if (originalEnv[key] === undefined) delete process.env[key];
    else process.env[key] = originalEnv[key];
  }
});

const request = (path, method = 'GET', body, headers = {}) => handler({
  httpMethod: method,
  rawUrl: `https://example.netlify.app/.netlify/functions/admin-portal${path}`,
  path: '/.netlify/functions/admin-portal',
  headers: { host: 'example.netlify.app', ...headers },
  body: body === undefined ? undefined : JSON.stringify(body)
});

test('health endpoint responds without an action parameter', async () => {
  const response = await request('');
  assert.equal(response.statusCode, 200);
  assert.equal(JSON.parse(response.body).status, 'available');
});

test('health endpoint does not expose environment values', async () => {
  const response = await request('');
  const body = response.body;
  assert.equal(body.includes(testPassword), false);
  assert.equal(body.includes(testSecret), false);
});

test('login rejects GET requests', async () => {
  const response = await request('?action=login');
  assert.equal(response.statusCode, 405);
});

test('login rejects incorrect credentials', async () => {
  const response = await request('?action=login', 'POST', { username: testUsername, password: 'wrong' });
  assert.equal(response.statusCode, 401);
});

test('login accepts correct credentials and issues a protected cookie', async () => {
  const response = await request('?action=login', 'POST', { username: testUsername, password: testPassword });
  assert.equal(response.statusCode, 200);
  assert.match(response.headers['Set-Cookie'], /HttpOnly/);
  assert.match(response.headers['Set-Cookie'], /Secure/);
  assert.match(response.headers['Set-Cookie'], /SameSite=Lax/);
  issuedCookie = response.headers['Set-Cookie'].split(';')[0];
  assert.equal(response.body.includes(testSecret), false);
});

test('session endpoint rejects requests without the cookie', async () => {
  const response = await request('?action=session');
  assert.equal(response.statusCode, 401);
});

test('session endpoint accepts a valid HttpOnly session cookie', async () => {
  const response = await request('?action=session', 'GET', undefined, { cookie: issuedCookie });
  assert.equal(response.statusCode, 200);
  assert.equal(JSON.parse(response.body).ok, true);
});

test('membership requests endpoint rejects requests without the cookie', async () => {
  const response = await request('?action=requests');
  assert.equal(response.statusCode, 401);
});
