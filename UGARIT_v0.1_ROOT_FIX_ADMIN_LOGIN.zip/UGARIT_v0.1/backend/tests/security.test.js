'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {signAccessToken,verifyAccessToken,hashPassword,verifyPassword,randomToken,sha256}=require('../src/security');
const secret='test-secret-that-is-at-least-32-characters-long';
test('access token signs and verifies claims',()=>{const t=signAccessToken({sub:'user-1',role:'student'},secret,60);const p=verifyAccessToken(t,secret);assert.equal(p.sub,'user-1');assert.equal(p.role,'student');});
test('access token rejects modified signature',()=>{const t=signAccessToken({sub:'user-1'},secret,60);assert.throws(()=>verifyAccessToken(t.slice(0,-1)+'x',secret));});
test('password hash verifies only the matching password',async()=>{const h=await hashPassword('a-strong-password-123');assert.equal(await verifyPassword('a-strong-password-123',h),true);assert.equal(await verifyPassword('wrong-password',h),false);});
test('refresh token material is random and stored as a digest',()=>{const a=randomToken(),b=randomToken();assert.notEqual(a,b);assert.notEqual(a,sha256(a));});
